import { PricingData, PricingResults } from "@/types/pricing";
import { getICMSRate, calcularICMS } from "./ncmData";

export const calculatePricing = (data: PricingData): PricingResults => {
  // Calculate tax based on product origin and NCM code
  const icmsRate = getICMSRate(
    data.ncmCode, 
    data.origin, 
    data.state || 'AM'
  );
  
  // Apply tax calculation using the provided formula
  let priceWithTaxes = data.purchasePrice;
  
  // If origin is national and from Amazonas, no entry tax is applied
  if (data.origin !== 'AM' && data.origin !== 'national') {
    const icmsValue = calcularICMS(data.purchasePrice, icmsRate);
    priceWithTaxes = data.purchasePrice + icmsValue;
  }

  // Convert desired margin from percentage to decimal for calculations
  const desiredMarginDecimal = data.desiredMargin / 100;
  
  // Calculate suggested price to achieve the desired profit margin
  // Formula: purchasePrice / (1 - desiredMargin)
  const suggestedPrice = priceWithTaxes / (1 - desiredMarginDecimal);
  
  // Calculate actual markup percentage
  const markup = ((suggestedPrice - priceWithTaxes) / priceWithTaxes) * 100;
  
  // Calculate profit margin (should match desired margin)
  const profitMargin = ((suggestedPrice - priceWithTaxes) / suggestedPrice) * 100;

  return {
    priceWithTaxes,
    markup,
    profitMargin,
    suggestedPrice,
    priceDifference: data.averagePrice > 0 
      ? ((suggestedPrice - data.averagePrice) / data.averagePrice) * 100
      : 0
  };
};

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
};

export const formatPercentage = (value: number): string => {
  return `${value.toFixed(2)}%`;
};
