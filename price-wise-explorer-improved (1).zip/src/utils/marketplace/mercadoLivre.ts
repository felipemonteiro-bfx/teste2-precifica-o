
interface MercadoLivreItem {
  id: string;
  title: string;
  price: number;
  permalink: string;
  thumbnail: string;
  seller: {
    nickname: string;
  };
}

interface MercadoLivreResponse {
  results: MercadoLivreItem[];
}

export const searchMercadoLivre = async (query: string): Promise<MercadoLivreItem[]> => {
  try {
    const response = await fetch(
      `https://api.mercadolibre.com/sites/MLB/search?q=${encodeURIComponent(query)}`
    );
    const data: MercadoLivreResponse = await response.json();
    return data.results.slice(0, 5);
  } catch (error) {
    console.error('Error fetching from Mercado Livre:', error);
    return [];
  }
};
