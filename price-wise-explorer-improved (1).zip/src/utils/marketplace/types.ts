
import { MarketListing } from '@/types/pricing';

export interface Marketplace {
  name: string;
  basePrice: number;
}

export interface SearchResult {
  item: MarketListing;
  score: number;
}

// Extended to include more clothing-related marketplaces
export interface NCMSuggestion {
  code: string;
  description: string;
  category?: string;
}
