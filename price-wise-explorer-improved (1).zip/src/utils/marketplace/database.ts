
import { Marketplace } from './types';

export const marketplaces: Marketplace[] = [
  { name: 'Amazon', basePrice: 100 },
  { name: 'Mercado Livre', basePrice: 90 },
  { name: 'Magazine Luiza', basePrice: 95 },
  { name: 'Americanas', basePrice: 85 },
  { name: 'Shopee', basePrice: 75 },
  { name: 'Casas Bahia', basePrice: 88 },
  { name: 'AliExpress', basePrice: 65 },
  { name: 'Dafiti', basePrice: 110 },
  { name: 'Renner', basePrice: 120 },
  { name: 'C&A', basePrice: 105 },
];
