import { MarketListing } from '@/types/pricing';
import { marketplaces } from './database';
import { getRandomImageUrl, normalizeSearchTerm, levenshteinDistance } from './utils';
import { SearchResult } from './types';
import { searchMercadoLivre } from './mercadoLivre';

const scoreSearchResults = (searchTerms: string[], listing: MarketListing): number => {
  let score = 0;
  
  searchTerms.forEach(term => {
    // Exact match in title
    if (listing.title.toLowerCase() === term) {
      score += 100;
    }
    // Partial match in title
    else if (listing.title.toLowerCase().includes(term)) {
      score += 50;
    }
    // Levenshtein distance-based match
    else if (term.length > 3) {
      const titleDistance = levenshteinDistance(term, listing.title.toLowerCase());
      if (titleDistance <= 2) {
        score += 25 - (titleDistance * 5);
      }
    }
  });
  
  return score;
};

const getMarketplaceSearchUrl = (productName: string, marketplace: string): string => {
  const encodedName = encodeURIComponent(productName);
  
  const marketplaceUrls: Record<string, string> = {
    'Mercado Livre': `https://www.mercadolivre.com.br/jm/search?as_word=${encodedName}`,
    'Amazon': `https://www.amazon.com.br/s?k=${encodedName}`,
    'Americanas': `https://www.americanas.com.br/busca/${encodedName.replace(/%20/g, '-')}`,
    'Magazine Luiza': `https://www.magazineluiza.com.br/busca/${encodedName.replace(/%20/g, '-')}`,
    'Shopee': `https://shopee.com.br/search?keyword=${encodedName}`,
    'Casas Bahia': `https://www.casasbahia.com.br/${encodedName.replace(/%20/g, '-')}`,
    'Ponto Frio': `https://www.pontofrio.com.br/${encodedName.replace(/%20/g, '-')}`,
    'Netshoes': `https://www.netshoes.com.br/busca?nsCat=Natural&q=${encodedName}`,
    'Renner': `https://www.lojasrenner.com.br/busca/${encodedName.replace(/%20/g, '-')}`,
    'Centauro': `https://www.centauro.com.br/busca?q=${encodedName}`,
    'Dafiti': `https://www.dafiti.com.br/catalog/?q=${encodedName}`,
    'Riachuelo': `https://www.riachuelo.com.br/catalogsearch/result/?q=${encodedName}`
  };
  
  return marketplaceUrls[marketplace] || `https://www.google.com/search?q=${encodedName}+${marketplace}`;
};

export const findSimilarListings = async (productName: string, state: string): Promise<MarketListing[]> => {
  if (!productName || productName.length < 3) return [];
  
  try {
    console.log(`Starting search for: "${productName}" in state: ${state}`);
    
    // Fetch real results from Mercado Livre
    const mlResults = await searchMercadoLivre(productName);
    
    // Convert Mercado Livre results to our format
    const realListings = mlResults.map(item => ({
      id: item.id,
      title: item.title,
      price: item.price,
      source: "Mercado Livre",
      imageUrl: item.thumbnail,
      link: item.permalink,
      seller: item.seller.nickname,
      state: state,
      relevance: 10
    }));

    // Generate simulated listings for other marketplaces
    const searchTerm = normalizeSearchTerm(productName);
    const searchTerms = searchTerm.split(/\s+/);
    
    const simulatedListings = marketplaces
      .filter(marketplace => marketplace.name !== "Mercado Livre")
      .map((marketplace, index) => {
        const priceVariation = Math.random() * 30 - 15;
        const price = marketplace.basePrice + priceVariation;
        
        return {
          id: `${marketplace.name.toLowerCase()}-${index}`,
          title: `${productName} - ${marketplace.name} Original`,
          price: price,
          source: `${marketplace.name} - ${state}`,
          imageUrl: getRandomImageUrl(productName),
          link: `https://www.google.com/search?q=${encodeURIComponent(productName)}+${encodeURIComponent(marketplace.name)}`,
          seller: marketplace.name,
          state: state,
          relevance: Math.random() * 5 + 5
        };
      });

    // Combine real and simulated results
    const allListings = [...realListings, ...simulatedListings];
    
    // Score and sort listings
    const scoredListings: SearchResult[] = allListings.map(listing => ({
      item: listing,
      score: scoreSearchResults(searchTerms, listing)
    }));
    
    // Sort by score and relevance
    const sortedListings = scoredListings
      .sort((a, b) => {
        if (a.item.source === "Mercado Livre" && b.item.source !== "Mercado Livre") return -1;
        if (a.item.source !== "Mercado Livre" && b.item.source === "Mercado Livre") return 1;
        return b.score - a.score;
      })
      .map(result => result.item);
    
    console.log(`Found ${sortedListings.length} similar products`);
    return sortedListings;
    
  } catch (error) {
    console.error('Error fetching listings:', error);
    return [];
  }
};

export const calculateAveragePrice = (listings: MarketListing[]): number => {
  if (!listings || listings.length === 0) return 0;
  
  const validListings = listings.filter(listing => 
    typeof listing.price === 'number' && !isNaN(listing.price) && listing.price > 0
  );
  
  if (validListings.length === 0) return 0;
  
  const totalPrice = validListings.reduce((sum, listing) => sum + listing.price, 0);
  return totalPrice / validListings.length;
};
