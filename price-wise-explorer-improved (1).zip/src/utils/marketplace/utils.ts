
// Helper function to generate a more realistic image URL based on product name
export const getRandomImageUrl = (productName: string) => {
  // Enhanced list of real product image placeholders
  const imageTemplates = [
    'https://placehold.co/400x300/purple/white?text=',
    'https://dummyimage.com/400x300/9370DB/ffffff.png&text=',
    'https://via.placeholder.com/400x300/8A2BE2/ffffff?text=',
    'https://placehold.co/400x300/5F4B8B/white?text='
  ];
  
  // Expanded categorization for products with image URLs
  const categories = {
    // Electronics
    'celular': 'https://placehold.co/400x300/00008B/white?text=Smartphone',
    'smartphone': 'https://placehold.co/400x300/00008B/white?text=Celular',
    'computador': 'https://placehold.co/400x300/4169E1/white?text=Computador',
    'notebook': 'https://placehold.co/400x300/4169E1/white?text=Notebook',
    'laptop': 'https://placehold.co/400x300/4169E1/white?text=Laptop',
    'tv': 'https://placehold.co/400x300/4682B4/white?text=Televisão',
    'televisão': 'https://placehold.co/400x300/4682B4/white?text=TV',
    'fone': 'https://placehold.co/400x300/1E90FF/white?text=Headphone',
    'headphone': 'https://placehold.co/400x300/1E90FF/white?text=Fone',
    'tablet': 'https://placehold.co/400x300/00BFFF/white?text=Tablet',
    'monitor': 'https://placehold.co/400x300/4682B4/white?text=Monitor',
    'console': 'https://placehold.co/400x300/191970/white?text=Console',
    
    // Clothing
    'roupa': 'https://placehold.co/400x300/9932CC/white?text=Moda',
    'camiseta': 'https://placehold.co/400x300/9932CC/white?text=Camiseta',
    'camisa': 'https://placehold.co/400x300/9932CC/white?text=Camisa',
    'calça': 'https://placehold.co/400x300/9932CC/white?text=Calça',
    'jeans': 'https://placehold.co/400x300/9932CC/white?text=Jeans',
    'vestido': 'https://placehold.co/400x300/FF1493/white?text=Vestido',
    'saia': 'https://placehold.co/400x300/FF1493/white?text=Saia',
    'blusa': 'https://placehold.co/400x300/FF1493/white?text=Blusa',
    'jaqueta': 'https://placehold.co/400x300/8B008B/white?text=Jaqueta',
    'casaco': 'https://placehold.co/400x300/8B008B/white?text=Casaco',
    'bolsa': 'https://placehold.co/400x300/FF00FF/white?text=Bolsa',
    'mochila': 'https://placehold.co/400x300/FF00FF/white?text=Mochila',
    
    // Footwear
    'sapato': 'https://placehold.co/400x300/800080/white?text=Calçado',
    'tênis': 'https://placehold.co/400x300/800080/white?text=Tênis',
    'tenis': 'https://placehold.co/400x300/800080/white?text=Tênis',
    'sandália': 'https://placehold.co/400x300/800080/white?text=Sandália',
    'bota': 'https://placehold.co/400x300/800080/white?text=Bota',
    
    // Home and furniture
    'sofá': 'https://placehold.co/400x300/A0522D/white?text=Sofá',
    'sofa': 'https://placehold.co/400x300/A0522D/white?text=Sofá',
    'mesa': 'https://placehold.co/400x300/8B4513/white?text=Mesa',
    'cadeira': 'https://placehold.co/400x300/8B4513/white?text=Cadeira',
    'armário': 'https://placehold.co/400x300/A0522D/white?text=Armário',
    'cama': 'https://placehold.co/400x300/DEB887/white?text=Cama',
    
    // Appliances
    'geladeira': 'https://placehold.co/400x300/708090/white?text=Geladeira',
    'fogão': 'https://placehold.co/400x300/708090/white?text=Fogão',
    'microondas': 'https://placehold.co/400x300/708090/white?text=Microondas',
    'máquina': 'https://placehold.co/400x300/708090/white?text=Máquina',
    'liquidificador': 'https://placehold.co/400x300/708090/white?text=Liquidificador',
    
    // Beauty and personal care
    'perfume': 'https://placehold.co/400x300/FF69B4/white?text=Perfume',
    'maquiagem': 'https://placehold.co/400x300/FF69B4/white?text=Maquiagem',
    'creme': 'https://placehold.co/400x300/FF69B4/white?text=Skincare',
    
    // Food
    'café': 'https://placehold.co/400x300/8B4513/white?text=Café',
    'cafe': 'https://placehold.co/400x300/8B4513/white?text=Café',
    'chocolate': 'https://placehold.co/400x300/8B4513/white?text=Chocolate',
    'leite': 'https://placehold.co/400x300/FFFFF0/black?text=Leite'
  };
  
  // Check if product name contains any of our category keywords
  const normalizedName = productName.toLowerCase();
  for (const [keyword, url] of Object.entries(categories)) {
    if (normalizedName.includes(keyword)) {
      return `${url}`;
    }
  }
  
  // If no matching category, use a random template with the product name
  const randomTemplate = imageTemplates[Math.floor(Math.random() * imageTemplates.length)];
  const encodedName = encodeURIComponent(productName);
  return `${randomTemplate}${encodedName}`;
};

// Helper function to sanitize and normalize search terms
export const normalizeSearchTerm = (term: string): string => {
  return term.trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s]/gi, '')
    .toLowerCase();
};

// Levenshtein distance implementation for fuzzy matching
export const levenshteinDistance = (a: string, b: string): number => {
  const matrix = [];

  // Initialize matrix
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  // Fill in the matrix
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      const cost = a[j - 1] === b[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,       // deletion
        matrix[i][j - 1] + 1,       // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );
    }
  }

  return matrix[b.length][a.length];
};
