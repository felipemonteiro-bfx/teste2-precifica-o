
import { PricingData, PricingResults } from '@/types/pricing';
import { formatCurrency, formatPercentage } from './pricingCalculations';

export const generateExportData = (data: PricingData, results: PricingResults) => {
  return {
    productName: data.productName || 'Não especificado',
    ncmCode: data.ncmCode || 'Não especificado',
    purchasePrice: formatCurrency(data.purchasePrice),
    origin: data.origin === 'local' ? 'Local' : 'Outro Estado',
    estimatedICMS: formatPercentage(data.importTax),
    averagePrice: formatCurrency(data.averagePrice),
    suggestedPrice: formatCurrency(results.suggestedPrice),
    markup: formatPercentage(results.markup),
    profitMargin: formatPercentage(results.profitMargin),
    marketDifference: formatPercentage(results.priceDifference || 0),
  };
};

export const downloadExcel = (data: PricingData, results: PricingResults) => {
  const exportData = generateExportData(data, results);
  const rows = [
    ['Simulação de Precificação'],
    [''],
    ['Nome do Produto', exportData.productName],
    ['Código NCM', exportData.ncmCode],
    ['Valor de Compra', exportData.purchasePrice],
    ['Origem', exportData.origin],
    ['ICMS Estimado', exportData.estimatedICMS],
    ['Preço Médio do Mercado', exportData.averagePrice],
    ['Preço Sugerido', exportData.suggestedPrice],
    [''],
    ['Indicadores'],
    ['Markup', exportData.markup],
    ['Margem de Lucro', exportData.profitMargin],
    ['Diferença do Mercado', exportData.marketDifference],
  ];

  let csvContent = rows.map(row => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = window.URL.createObjectURL(blob);
  link.setAttribute('download', `simulacao-${data.productName || 'produto'}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
