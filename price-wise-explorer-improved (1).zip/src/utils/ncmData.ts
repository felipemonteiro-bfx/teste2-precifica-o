import { NCMSuggestion } from './marketplace/types';

// Sample NCM data with expanded categories as fallback
const ncmDatabase: NCMSuggestion[] = [
  // Eletrônicos
  { code: "8517.12.31", description: "Telefones celulares", category: "Eletrônicos" },
  { code: "8471.30.12", description: "Computadores portáteis", category: "Eletrônicos" },
  { code: "8528.72.00", description: "Televisores", category: "Eletrônicos" },
  { code: "8518.22.00", description: "Alto-falantes", category: "Eletrônicos" },
  { code: "8521.90.90", description: "Reprodutores de vídeo", category: "Eletrônicos" },
  
  // Vestuário
  { code: "6101.20.00", description: "Casacos masculinos de algodão", category: "Vestuário" },
  { code: "6102.30.00", description: "Casacos femininos sintéticos", category: "Vestuário" },
  { code: "6104.42.00", description: "Vestidos de algodão", category: "Vestuário" },
  { code: "6105.10.00", description: "Camisas masculinas de algodão", category: "Vestuário" },
  { code: "6106.10.00", description: "Camisas femininas de algodão", category: "Vestuário" },
  { code: "6109.10.00", description: "Camisetas de algodão", category: "Vestuário" },
  { code: "6203.42.00", description: "Calças masculinas de algodão", category: "Vestuário" },
  { code: "6204.62.00", description: "Calças femininas de algodão", category: "Vestuário" },
  { code: "6404.11.00", description: "Calçados esportivos", category: "Vestuário" },
  
  // Alimentos
  { code: "1101.00.10", description: "Farinha de trigo", category: "Alimentos" },
  { code: "0901.21.00", description: "Café torrado", category: "Alimentos" },
  { code: "1701.99.00", description: "Açúcar refinado", category: "Alimentos" },
  { code: "1902.19.00", description: "Massas alimentícias", category: "Alimentos" },
  
  // Móveis
  { code: "9401.30.10", description: "Assentos giratórios", category: "Móveis" },
  { code: "9403.20.00", description: "Móveis de metal", category: "Móveis" },
  { code: "9403.50.00", description: "Móveis de madeira para quartos", category: "Móveis" },
  { code: "9403.60.00", description: "Outros móveis de madeira", category: "Móveis" },
  
  // Cosméticos
  { code: "3304.99.90", description: "Produtos de beleza", category: "Cosméticos" },
  { code: "3305.10.00", description: "Shampoos", category: "Cosméticos" },
  { code: "3306.10.00", description: "Dentifrícios", category: "Cosméticos" },
];

// Função para buscar NCM da Brasil API
const searchNCMFromAPI = async (searchTerm: string): Promise<NCMSuggestion[]> => {
  try {
    const normalizedTerm = searchTerm.normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
    
    // Endpoint da Brasil API para busca de NCM
    const url = `https://brasilapi.com.br/api/ncm/v1?search=${encodeURIComponent(normalizedTerm)}`;
    
    console.log(`Buscando NCM na API externa: ${url}`);
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`Erro na API: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Transformar os resultados da API no formato NCMSuggestion
    const apiResults: NCMSuggestion[] = data.map((item: any) => ({
      code: item.codigo,
      description: item.descricao,
      category: determineCategory(item.descricao)
    }));
    
    console.log(`API retornou ${apiResults.length} resultados para "${searchTerm}"`);
    return apiResults;
  } catch (error) {
    console.error('Erro ao buscar NCM da API:', error);
    return [];
  }
};

// Função para determinar a categoria com base na descrição
const determineCategory = (description: string): string => {
  const normalizedDesc = description.normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
  
  const categoryMap: {[key: string]: string} = {
    'eletron': 'Eletrônicos',
    'computador': 'Eletrônicos',
    'telefone': 'Eletrônicos',
    'celular': 'Eletrônicos',
    'tv': 'Eletrônicos',
    'televisor': 'Eletrônicos',
    'audio': 'Eletrônicos',
    'som': 'Eletrônicos',
    
    'roupa': 'Vestuário',
    'vestido': 'Vestuário',
    'calca': 'Vestuário',
    'camisa': 'Vestuário',
    'calcado': 'Vestuário',
    'sapato': 'Vestuário',
    'tenis': 'Vestuário',
    'algodao': 'Vestuário',
    
    'alimento': 'Alimentos',
    'comida': 'Alimentos',
    'bebida': 'Alimentos',
    'cafe': 'Alimentos',
    'acucar': 'Alimentos',
    'farinha': 'Alimentos',
    
    'movel': 'Móveis',
    'mesa': 'Móveis',
    'cadeira': 'Móveis',
    'assento': 'Móveis',
    'madeira': 'Móveis',
    
    'cosmetico': 'Cosméticos',
    'beleza': 'Cosméticos',
    'perfume': 'Cosméticos',
    'shampoo': 'Cosméticos',
    'higiene': 'Cosméticos',
  };
  
  for (const [keyword, category] of Object.entries(categoryMap)) {
    if (normalizedDesc.includes(keyword)) {
      return category;
    }
  }
  
  return 'Outros';
};

// Função principal para buscar sugestões de NCM
export const findNCMSuggestions = async (searchTerm: string): Promise<NCMSuggestion[]> => {
  if (!searchTerm || searchTerm.length < 2) return [];
  
  try {
    console.log(`Buscando NCM para: ${searchTerm}`);
    
    // Primeiro tenta buscar da API externa
    const apiResults = await searchNCMFromAPI(searchTerm);
    
    // Se encontrou resultados na API, retorna eles
    if (apiResults.length > 0) {
      console.log(`Encontrados ${apiResults.length} resultados na API externa`);
      return apiResults;
    }
    
    // Caso contrário, busca no banco de dados local como fallback
    console.log(`Nenhum resultado encontrado na API, buscando no banco local`);
    
    // Normalize search term (remove accents, lowercase)
    const normalizedTerm = searchTerm.normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
    
    // Search in both code and description with fuzzy matching
    const results = ncmDatabase.filter(item => {
      const normalizedDesc = item.description.normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase();
      
      const normalizedCategory = item.category?.normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase() || '';
      
      // Check if search term is in code, description or category
      return item.code.includes(normalizedTerm) || 
             normalizedDesc.includes(normalizedTerm) ||
             normalizedCategory.includes(normalizedTerm);
    });
    
    console.log(`Encontrados ${results.length} resultados no banco local`);
    return results;
  } catch (error) {
    console.error('Erro ao buscar sugestões de NCM:', error);
    return [];
  }
};

// Função para buscar um NCM específico pelo código
export const getNCMByCode = async (code: string): Promise<NCMSuggestion | null> => {
  if (!code) return null;
  
  try {
    // Tenta buscar da API externa
    const url = `https://brasilapi.com.br/api/ncm/v1/${code.replace(/\./g, '')}`;
    console.log(`Buscando NCM específico na API: ${url}`);
    
    const response = await fetch(url);
    
    if (response.ok) {
      const item = await response.json();
      return {
        code: item.codigo,
        description: item.descricao,
        category: determineCategory(item.descricao)
      };
    }
    
    // Se não encontrou na API, busca no banco local
    console.log(`NCM não encontrado na API, buscando no banco local`);
    const localResult = ncmDatabase.find(item => item.code.replace(/\./g, '') === code.replace(/\./g, ''));
    return localResult || null;
  } catch (error) {
    console.error('Erro ao buscar NCM específico:', error);
    
    // Tenta no banco local em caso de erro
    const localResult = ncmDatabase.find(item => item.code.replace(/\./g, '') === code.replace(/\./g, ''));
    return localResult || null;
  }
};

// ICMS tax calculation functions
export const getICMSRate = (ncmCode: string, origin: string, state: string): number => {
  // Default rates for different origins
  const defaultRates = {
    'local': 0,
    'other-state': 12
  };
  
  // You could expand this with actual NCM-specific rates in the future
  return defaultRates[origin as keyof typeof defaultRates] || 0;
};

export const calcularICMS = (value: number, taxRate: number): number => {
  return value * (taxRate / 100);
};
