
import { useState, useEffect } from 'react';
import { MarketListing, PricingData, PricingResults } from '@/types/pricing';
import { calculatePricing } from '@/utils/pricingCalculations';
import { findSimilarListings, calculateAveragePrice } from '@/utils/marketData';
import { searchMercadoLivre } from '@/utils/marketplace/mercadoLivre';
import { toast } from '@/components/ui/sonner';

export const usePricingCalculator = () => {
  const [data, setData] = useState<PricingData>({
    productName: '',
    ncmCode: '',
    ncmSuggestions: [],
    origin: 'AM',
    purchasePrice: 0,
    city: '',
    state: 'AM',
    importTax: 0,
    desiredMargin: 45,
    averagePrice: 0,
  });

  const [results, setResults] = useState<PricingResults>({
    priceWithTaxes: 0,
    markup: 0,
    profitMargin: 0,
    suggestedPrice: 0,
  });

  const [marketListings, setMarketListings] = useState<MarketListing[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof PricingData, value: string | number | Array<{code: string, description: string}>) => {
    setData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateData = (): boolean => {
    if (data.purchasePrice <= 0) {
      toast.error("Valor de compra deve ser maior que zero");
      return false;
    }
    
    if (data.desiredMargin < 5 || data.desiredMargin > 300) {
      toast.error("Margem desejada deve estar entre 5% e 300%");
      return false;
    }
    
    if (!data.productName) {
      toast.error("Digite o nome do produto");
      return false;
    }
    
    return true;
  };

  const fetchMarketListings = async () => {
    if (data.productName.length >= 3) {
      setIsLoading(true);
      try {
        console.log(`Buscando produtos similares para: ${data.productName} em ${data.state}`);
        toast.info(`Buscando produtos similares para: ${data.productName}`);
        
        const mlResults = await searchMercadoLivre(data.productName);
        const realListings = mlResults.map(item => ({
          id: item.id,
          title: item.title,
          price: item.price,
          source: "Mercado Livre",
          imageUrl: item.thumbnail,
          link: item.permalink,
          seller: item.seller.nickname,
          state: data.state,
          relevance: 10
        }));
        
        const listings = realListings.length > 0 
          ? realListings 
          : await findSimilarListings(data.productName, data.state);
        
        setMarketListings(listings);
        const avgPrice = calculateAveragePrice(listings);
        handleInputChange('averagePrice', avgPrice);
        
        if (listings.length > 0) {
          toast.success(`Encontramos ${listings.length} produtos similares em ${data.state}`);
        } else {
          toast.warning(`Não encontramos produtos similares para "${data.productName}". Tente outro termo de busca.`);
        }
      } catch (error) {
        console.error("Erro ao buscar produtos similares:", error);
        toast.error("Erro ao buscar produtos similares. Tente novamente mais tarde.");
      } finally {
        setIsLoading(false);
      }
    } else {
      setMarketListings([]);
    }
  };

  useEffect(() => {
    const debounceTimer = setTimeout(fetchMarketListings, 800);
    return () => clearTimeout(debounceTimer);
  }, [data.productName, data.state]);

  useEffect(() => {
    if (validateData()) {
      const newResults = calculatePricing(data);
      setResults(newResults);
    }
  }, [data]);

  return {
    data,
    results,
    marketListings,
    isLoading,
    handleInputChange,
    fetchMarketListings,
    validateData
  };
};

