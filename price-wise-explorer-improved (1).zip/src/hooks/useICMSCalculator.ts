
import { useState } from 'react';
import { ICMSInputs, ICMSCalculation } from "@/types/icms";

export const useICMSCalculator = () => {
  const [inputs, setInputs] = useState<ICMSInputs>({
    merchandiseValue: 0,
    ipi: 0,
    freight: 0,
    insurance: 0,
    origin: 'national',
    originState: '',
    originRate: 12,
    amRate: 20,
  });

  const [result, setResult] = useState<ICMSCalculation>({
    baseValue: 0,
    icmsValue: 0,
    method: 'interstate',
    isValid: false,
  });

  const calculateICMS = () => {
    if (inputs.merchandiseValue <= 0) return;

    const base = inputs.merchandiseValue + 
                (inputs.ipi || 0) + 
                (inputs.freight || 0) + 
                (inputs.insurance || 0);

    let icmsValue = 0;
    const method = inputs.origin === 'national' ? 'interstate' : 'import';

    if (inputs.origin === 'national' && inputs.originState === 'AM') {
      icmsValue = 0;
    } else if (inputs.origin === 'national') {
      icmsValue = (base * (inputs.amRate / 100)) - (base * (inputs.originRate / 100));
    } else {
      icmsValue = (base / (1 - inputs.amRate / 100)) * (inputs.amRate / 100);
    }

    setResult({
      baseValue: base,
      icmsValue: icmsValue,
      method,
      isValid: true
    });
  };

  const handleOriginStateChange = (state: string) => {
    let rate = 12;
    if (['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'GO', 'MA', 'MT', 
         'MS', 'PA', 'PB', 'PE', 'PI', 'RN', 'RO', 'RR', 'SE', 'TO'].includes(state)) {
      rate = 7;
    }
    
    setInputs(prev => ({
      ...prev,
      originState: state,
      originRate: rate
    }));
  };

  const updateInput = (field: keyof ICMSInputs, value: number | string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  return {
    inputs,
    result,
    updateInput,
    handleOriginStateChange,
    calculateICMS
  };
};
