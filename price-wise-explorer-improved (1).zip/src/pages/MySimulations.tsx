
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/sonner';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatCurrency, formatPercentage } from '@/utils/pricingCalculations';
import { Pencil, Trash, Copy, FileSpreadsheet } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PricingData, PricingResults } from '@/types/pricing';
import { downloadExcel } from '@/utils/exportUtils';

interface SimulationRecord {
  id: number;
  created_at: string;
  product_name: string;
  ncm_code: string;
  purchase_price: number;
  suggested_price: number;
  markup: number;
  profit_margin: number;
}

const MySimulations = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [simulations, setSimulations] = useState<SimulationRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    
    const fetchSimulations = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('simulations')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        setSimulations(data || []);
      } catch (error) {
        console.error('Error fetching simulations:', error);
        toast.error('Erro ao carregar simulações. Tente novamente.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchSimulations();
  }, [user]);

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir esta simulação?')) return;
    
    try {
      const { error } = await supabase
        .from('simulations')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      setSimulations(prev => prev.filter(sim => sim.id !== id));
      toast.success('Simulação excluída com sucesso!');
    } catch (error) {
      console.error('Error deleting simulation:', error);
      toast.error('Erro ao excluir simulação. Tente novamente.');
    }
  };

  const handleExport = (simulation: SimulationRecord) => {
    try {
      // Convert simulation to required format
      const data: PricingData = {
        productName: simulation.product_name,
        ncmCode: simulation.ncm_code,
        origin: 'local',
        purchasePrice: simulation.purchase_price,
        city: '',
        state: 'AM',
        importTax: 0,
        desiredMargin: simulation.profit_margin,
        averagePrice: 0,
        ncmSuggestions: []
      };
      
      const results: PricingResults = {
        priceWithTaxes: simulation.purchase_price,
        markup: simulation.markup,
        profitMargin: simulation.profit_margin,
        suggestedPrice: simulation.suggested_price
      };
      
      downloadExcel(data, results);
      toast.success('Simulação exportada com sucesso!');
    } catch (error) {
      console.error('Error exporting simulation:', error);
      toast.error('Erro ao exportar simulação. Tente novamente.');
    }
  };

  const handleDuplicate = async (simulation: SimulationRecord) => {
    try {
      const { error } = await supabase
        .from('simulations')
        .insert({
          user_id: user?.id,
          product_name: `${simulation.product_name} (cópia)`,
          ncm_code: simulation.ncm_code,
          purchase_price: simulation.purchase_price,
          suggested_price: simulation.suggested_price,
          markup: simulation.markup,
          profit_margin: simulation.profit_margin
        });
      
      if (error) throw error;
      
      toast.success('Simulação duplicada com sucesso!');
      
      // Refresh the list
      const { data: newData, error: fetchError } = await supabase
        .from('simulations')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      
      if (fetchError) throw fetchError;
      
      setSimulations(newData || []);
    } catch (error) {
      console.error('Error duplicating simulation:', error);
      toast.error('Erro ao duplicar simulação. Tente novamente.');
    }
  };

  return (
    <div className="container mx-auto p-4 max-w-5xl">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-600">
        Minhas Simulações
      </h1>
      
      <Card className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Histórico de Simulações</h2>
          <Button onClick={() => navigate('/')} variant="outline">
            Nova Simulação
          </Button>
        </div>
        
        {isLoading ? (
          <div className="py-10 text-center">
            <div className="animate-spin h-10 w-10 border-4 border-purple-500 rounded-full border-t-transparent mx-auto"></div>
            <p className="text-gray-500 mt-4">Carregando suas simulações...</p>
          </div>
        ) : simulations.length === 0 ? (
          <div className="py-10 text-center border border-dashed rounded-md">
            <p className="text-gray-500 mb-4">Você ainda não tem simulações salvas.</p>
            <Button onClick={() => navigate('/')} variant="default">
              Criar Primeira Simulação
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Produto</TableHead>
                  <TableHead>Preço de Compra</TableHead>
                  <TableHead>Preço Sugerido</TableHead>
                  <TableHead>Margem</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {simulations.map((sim) => (
                  <TableRow key={sim.id}>
                    <TableCell>
                      {new Date(sim.created_at).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="font-medium">
                      {sim.product_name}
                      <div className="text-xs text-gray-500">{sim.ncm_code}</div>
                    </TableCell>
                    <TableCell>
                      {formatCurrency(sim.purchase_price)}
                    </TableCell>
                    <TableCell>
                      {formatCurrency(sim.suggested_price)}
                    </TableCell>
                    <TableCell>
                      {formatPercentage(sim.profit_margin)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleExport(sim)}
                          title="Exportar"
                        >
                          <FileSpreadsheet className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDuplicate(sim)}
                          title="Duplicar"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDelete(sim.id)}
                          className="text-red-500 hover:text-red-700"
                          title="Excluir"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default MySimulations;
