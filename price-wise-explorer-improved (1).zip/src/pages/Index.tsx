
import React from 'react';
import PricingCalculator from '@/components/PricingCalculator';
import PaymentProfile from '@/components/payment/PaymentProfile';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <div className="w-full sm:w-auto">
            <Tabs defaultValue="pricing" className="w-full">
              <TabsList className="w-full sm:w-auto">
                <TabsTrigger value="pricing">Precificação</TabsTrigger>
                <TabsTrigger value="payment">Pagamentos</TabsTrigger>
              </TabsList>
              
              <TabsContent value="pricing">
                <PricingCalculator />
              </TabsContent>
              
              <TabsContent value="payment">
                <div className="max-w-2xl mx-auto">
                  <h1 className="text-3xl font-bold text-center mb-8 text-purple-600">
                    Gerenciamento de Pagamentos
                  </h1>
                  <PaymentProfile />
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <Link to="/simulacoes">
            <Button variant="outline" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Minhas Simulações
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Index;
