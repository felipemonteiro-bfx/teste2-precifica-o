import { useNavigate } from "react-router-dom";
import LoginForm from "@/components/auth/LoginForm";
import { ResetPasswordForm } from "@/components/auth/ResetPasswordForm";
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/components/ui/sonner";
import { supabase } from "@/lib/supabase";
import { Calculator } from "lucide-react";

const Login = () => {
  const navigate = useNavigate();
  const [showResetForm, setShowResetForm] = useState(false);
  const { user, loading } = useAuth();
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [connectionError, setConnectionError] = useState(false);
  const [devMode, setDevMode] = useState(false);
  
  useEffect(() => {
    const isDevelopmentMode = !import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY;
    if (isDevelopmentMode) {
      setDevMode(true);
      console.info('Running in development mode without Supabase connection');
    }
    
    const checkSession = async () => {
      try {
        console.log("Iniciando verificação de sessão...");
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error("Erro ao obter sessão:", error.message);
          setConnectionError(true);
          toast.error("Erro de conexão com o servidor. Tente novamente.");
        } else if (data.session) {
          console.log("Sessão ativa encontrada", data.session);
          toast.success("Sessão recuperada com sucesso!");
        } else {
          console.log("Nenhuma sessão ativa encontrada");
        }
      } catch (error) {
        console.error("Exceção ao verificar sessão:", error);
        setConnectionError(true);
        toast.error("Erro ao conectar com o servidor de autenticação.");
      } finally {
        setIsCheckingAuth(false);
      }
    };
    
    checkSession();
  }, []);
  
  useEffect(() => {
    if (!loading && user) {
      console.log("Usuário autenticado, redirecionando para home", user);
      toast.success("Login realizado com sucesso!");
      navigate("/");
    }
  }, [user, loading, navigate]);
  
  if (loading || isCheckingAuth) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="animate-spin h-10 w-10 border-4 border-purple-500 rounded-full border-t-transparent mb-4"></div>
        <p className="text-purple-600 font-medium">Verificando autenticação...</p>
        <p className="text-gray-500 text-sm mt-2">Aguarde um momento</p>
      </div>
    );
  }

  if (user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin h-10 w-10 border-4 border-purple-500 rounded-full border-t-transparent mb-4"></div>
        <p className="text-purple-600 font-medium ml-3">Redirecionando...</p>
      </div>
    );
  }

  const handleResetPassword = async (email: string) => {
    try {
      toast.info("Enviando link de recuperação...");
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) throw error;
      
      toast.success(`Link de recuperação enviado para ${email}`);
      setShowResetForm(false);
    } catch (error: any) {
      console.error("Erro ao enviar link de recuperação:", error);
      toast.error(error.message || "Erro ao enviar link de recuperação");
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-between p-4">
      <div className="w-full max-w-md flex-1 flex flex-col items-center justify-center">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Calculator className="w-10 h-10 text-purple-600" />
            <h1 className="text-4xl font-bold text-purple-600">CalculeX</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Otimize sua precificação com IA e aumente sua margem de lucro.
          </p>
        </div>

        {devMode && (
          <div className="mb-4 p-3 bg-yellow-50 text-yellow-800 border border-yellow-200 rounded-md text-sm max-w-md">
            <p className="font-medium mb-1">🔧 Modo de Desenvolvimento</p>
            <p>Supabase não está configurado. Para configurar o Supabase:</p>
            <ol className="list-decimal pl-5 mt-1 space-y-1">
              <li>Crie um projeto no <a href="https://supabase.com" className="text-purple-600 underline" target="_blank" rel="noopener noreferrer">Supabase</a></li>
              <li>Configure as variáveis de ambiente:
                <ul className="list-disc pl-5 mt-1">
                  <li>VITE_SUPABASE_URL</li>
                  <li>VITE_SUPABASE_ANON_KEY</li>
                </ul>
              </li>
            </ol>
          </div>
        )}
        
        {connectionError && !devMode && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 border border-red-200 rounded-md text-sm">
            Estamos com dificuldade de conectar ao servidor. Tente recarregar a página.
            <button 
              className="ml-2 underline" 
              onClick={() => window.location.reload()}
            >
              Recarregar agora
            </button>
          </div>
        )}
        
        {showResetForm ? (
          <ResetPasswordForm 
            onSubmit={handleResetPassword}
            onCancel={() => setShowResetForm(false)}
          />
        ) : (
          <LoginForm 
            onForgotPassword={() => setShowResetForm(true)}
          />
        )}
      </div>

      <div className="w-full text-center py-4 text-sm text-gray-500">
        <a href="/privacy" className="hover:text-purple-600 mx-2">
          Política de Privacidade
        </a>
        <span>•</span>
        <a href="/terms" className="hover:text-purple-600 mx-2">
          Termos de Uso
        </a>
      </div>
    </div>
  );
};

export default Login;
