import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/sonner';

// Tipos para os dados de compras
interface PurchaseItem {
  id: string;
  productName: string;
  ncmCode: string;
  purchasePrice: number;
  suggestedPrice: number;
  supplier: string;
  purchaseDate: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  category: string;
}

interface CategorySummary {
  name: string;
  value: number;
  count: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export const ProcurementDashboard = () => {
  const { user } = useAuth();
  const [purchaseItems, setPurchaseItems] = useState<PurchaseItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryData, setCategoryData] = useState<CategorySummary[]>([]);
  const [statusData, setStatusData] = useState<{name: string, value: number}[]>([]);
  const [selectedTab, setSelectedTab] = useState('overview');
  
  // Função para carregar os dados de compras
  const loadPurchaseData = async () => {
    setLoading(true);
    try {
      // Simulação de dados - em produção, isso viria do banco de dados
      const mockData: PurchaseItem[] = [
        {
          id: '1',
          productName: 'Notebook Dell XPS 13',
          ncmCode: '8471.30.12',
          purchasePrice: 7500,
          suggestedPrice: 9200,
          supplier: 'Dell Computadores',
          purchaseDate: '2025-04-15',
          status: 'completed',
          category: 'Eletrônicos'
        },
        {
          id: '2',
          productName: 'Monitor LG 27"',
          ncmCode: '8528.52.00',
          purchasePrice: 1200,
          suggestedPrice: 1550,
          supplier: 'LG Brasil',
          purchaseDate: '2025-04-18',
          status: 'approved',
          category: 'Eletrônicos'
        },
        {
          id: '3',
          productName: 'Cadeira Ergonômica',
          ncmCode: '9401.30.10',
          purchasePrice: 850,
          suggestedPrice: 1100,
          supplier: 'Office Móveis',
          purchaseDate: '2025-04-10',
          status: 'completed',
          category: 'Móveis'
        },
        {
          id: '4',
          productName: 'Mesa de Escritório',
          ncmCode: '9403.30.00',
          purchasePrice: 1300,
          suggestedPrice: 1680,
          supplier: 'Office Móveis',
          purchaseDate: '2025-04-05',
          status: 'completed',
          category: 'Móveis'
        },
        {
          id: '5',
          productName: 'Impressora HP LaserJet',
          ncmCode: '8443.31.00',
          purchasePrice: 2200,
          suggestedPrice: 2850,
          supplier: 'HP Brasil',
          purchaseDate: '2025-04-20',
          status: 'pending',
          category: 'Eletrônicos'
        },
        {
          id: '6',
          productName: 'Smartphone Samsung Galaxy',
          ncmCode: '8517.12.31',
          purchasePrice: 3500,
          suggestedPrice: 4550,
          supplier: 'Samsung Brasil',
          purchaseDate: '2025-04-12',
          status: 'approved',
          category: 'Eletrônicos'
        },
        {
          id: '7',
          productName: 'Cafeteira Industrial',
          ncmCode: '8516.71.00',
          purchasePrice: 950,
          suggestedPrice: 1235,
          supplier: 'Equipamentos Gastronômicos',
          purchaseDate: '2025-04-08',
          status: 'rejected',
          category: 'Eletrodomésticos'
        },
      ];
      
      setPurchaseItems(mockData);
      
      // Processar dados para os gráficos
      processChartData(mockData);
    } catch (error) {
      console.error('Erro ao carregar dados de compras:', error);
      toast.error('Erro ao carregar dados de compras');
    } finally {
      setLoading(false);
    }
  };
  
  // Processar dados para os gráficos
  const processChartData = (data: PurchaseItem[]) => {
    // Dados por categoria
    const categoryMap = new Map<string, {total: number, count: number}>();
    data.forEach(item => {
      const current = categoryMap.get(item.category) || {total: 0, count: 0};
      categoryMap.set(item.category, {
        total: current.total + item.purchasePrice,
        count: current.count + 1
      });
    });
    
    const categoryChartData: CategorySummary[] = Array.from(categoryMap.entries()).map(([name, {total, count}]) => ({
      name,
      value: total,
      count
    }));
    
    setCategoryData(categoryChartData);
    
    // Dados por status
    const statusMap = new Map<string, number>();
    data.forEach(item => {
      const current = statusMap.get(item.status) || 0;
      statusMap.set(item.status, current + 1);
    });
    
    const statusChartData = Array.from(statusMap.entries()).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value
    }));
    
    setStatusData(statusChartData);
  };
  
  // Filtrar itens com base no termo de busca
  const filteredItems = purchaseItems.filter(item => 
    item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.ncmCode.includes(searchTerm)
  );
  
  // Carregar dados ao montar o componente
  useEffect(() => {
    loadPurchaseData();
  }, []);
  
  // Função para exportar dados para CSV
  const exportToCSV = () => {
    const headers = ['Produto', 'Código NCM', 'Preço de Compra', 'Preço Sugerido', 'Fornecedor', 'Data', 'Status', 'Categoria'];
    const csvData = filteredItems.map(item => [
      item.productName,
      item.ncmCode,
      item.purchasePrice.toString(),
      item.suggestedPrice.toString(),
      item.supplier,
      item.purchaseDate,
      item.status,
      item.category
    ]);
    
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `compras_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Relatório exportado com sucesso!');
  };
  
  // Função para obter a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'approved': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      case 'rejected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };
  
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Dashboard de Compras</h1>
      
      <Tabs defaultValue="overview" onValueChange={setSelectedTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="purchases">Compras</TabsTrigger>
          <TabsTrigger value="analytics">Análises</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Total de Compras</CardTitle>
                <CardDescription>Valor total de todas as compras</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">
                  R$ {purchaseItems.reduce((sum, item) => sum + item.purchasePrice, 0).toLocaleString('pt-BR')}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Economia Estimada</CardTitle>
                <CardDescription>Diferença entre preço sugerido e preço de compra</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-green-600">
                  R$ {purchaseItems.reduce((sum, item) => sum + (item.suggestedPrice - item.purchasePrice), 0).toLocaleString('pt-BR')}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Compras Pendentes</CardTitle>
                <CardDescription>Compras aguardando aprovação</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-yellow-600">
                  {purchaseItems.filter(item => item.status === 'pending').length}
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Compras por Categoria</CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Status das Compras</CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={statusData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Quantidade" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="purchases">
          <div className="flex justify-between items-center mb-4">
            <div className="w-1/3">
              <Input
                placeholder="Buscar por produto, fornecedor ou NCM..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button onClick={exportToCSV}>Exportar para CSV</Button>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableCaption>Lista de compras realizadas e pendentes</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produto</TableHead>
                    <TableHead>Código NCM</TableHead>
                    <TableHead>Preço de Compra</TableHead>
                    <TableHead>Preço Sugerido</TableHead>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Categoria</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center">Carregando dados...</TableCell>
                    </TableRow>
                  ) : filteredItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center">Nenhum item encontrado</TableCell>
                    </TableRow>
                  ) : (
                    filteredItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell>{item.ncmCode}</TableCell>
                        <TableCell>R$ {item.purchasePrice.toLocaleString('pt-BR')}</TableCell>
                        <TableCell>R$ {item.suggestedPrice.toLocaleString('pt-BR')}</TableCell>
                        <TableCell>{item.supplier}</TableCell>
                        <TableCell>{new Date(item.purchaseDate).toLocaleDateString('pt-BR')}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(item.status)}>
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>{item.category}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Economia por Categoria</CardTitle>
                <CardDescription>Diferença entre preço sugerido e preço de compra por categoria</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categoryData.map(cat => {
                      const items = purchaseItems.filter(item => item.category === cat.name);
                      const savings = items.reduce((sum, item) => sum + (item.suggestedPrice - item.purchasePrice), 0);
                      return {
                        name: cat.name,
                        value: savings
                      };
                    })}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`} />
                    <Legend />
                    <Bar dataKey="value" name="Economia" fill="#00C49F" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Quantidade de Itens por Categoria</CardTitle>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categoryData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" name="Quantidade" fill="#FFBB28" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Resumo de Compras por Fornecedor</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead>Total de Compras</TableHead>
                    <TableHead>Valor Total</TableHead>
                    <TableHead>Economia Total</TableHead>
                    <TableHead>Média de Economia</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Array.from(new Set(purchaseItems.map(item => item.supplier))).map(supplier => {
                    const items = purchaseItems.filter(item => item.supplier === supplier);
                    const totalValue = items.reduce((sum, item) => sum + item.purchasePrice, 0);
                    const totalSavings = items.reduce((sum, item) => sum + (item.suggestedPrice - item.purchasePrice), 0);
                    const avgSavings = totalSavings / items.length;
                    
                    return (
                      <TableRow key={supplier}>
                        <TableCell>{supplier}</TableCell>
                        <TableCell>{items.length}</TableCell>
                        <TableCell>R$ {totalValue.toLocaleString('pt-BR')}</TableCell>
                        <TableCell>R$ {totalSavings.toLocaleString('pt-BR')}</TableCell>
                        <TableCell>R$ {avgSavings.toLocaleString('pt-BR')}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProcurementDashboard;
