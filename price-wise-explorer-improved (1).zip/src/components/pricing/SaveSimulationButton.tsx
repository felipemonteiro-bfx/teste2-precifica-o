
import React from 'react';
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";

interface SaveSimulationButtonProps {
  onClick: () => void;
}

const SaveSimulationButton = ({ onClick }: SaveSimulationButtonProps) => {
  return (
    <Button
      onClick={onClick}
      variant="default"
      className="w-full flex items-center gap-2 bg-purple-600 hover:bg-purple-700"
    >
      <Save className="h-4 w-4" />
      Salvar Simulação
    </Button>
  );
};

export default SaveSimulationButton;
