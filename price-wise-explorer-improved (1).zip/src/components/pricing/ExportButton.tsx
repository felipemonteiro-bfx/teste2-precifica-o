
import React from 'react';
import { Button } from "@/components/ui/button";
import { FileSpreadsheet } from "lucide-react";
import { PricingData, PricingResults } from '@/types/pricing';
import { downloadExcel } from '@/utils/exportUtils';
import { toast } from '@/components/ui/sonner';

interface ExportButtonProps {
  data: PricingData;
  results: PricingResults;
}

const ExportButton = ({ data, results }: ExportButtonProps) => {
  const handleExport = () => {
    try {
      if (!data.productName) {
        toast.error("Por favor, insira o nome do produto antes de exportar");
        return;
      }
      
      downloadExcel(data, results);
      toast.success("Simulação exportada com sucesso!");
    } catch (error) {
      console.error('Error exporting data:', error);
      toast.error("Erro ao exportar simulação");
    }
  };

  return (
    <Button
      onClick={handleExport}
      variant="outline"
      className="w-full flex items-center gap-2"
    >
      <FileSpreadsheet className="h-4 w-4" />
      Exportar Simulação
    </Button>
  );
};

export default ExportButton;
