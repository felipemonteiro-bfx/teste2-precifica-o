
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { PricingData } from "@/types/pricing";

interface PricingInputsProps {
  data: Pick<PricingData, 'purchasePrice' | 'desiredMargin' | 'importTax' | 'averagePrice' | 'origin'>;
  onDataChange: (field: keyof PricingData, value: number) => void;
  isLoading?: boolean;
}

const PricingInputs = ({ data, onDataChange, isLoading = false }: PricingInputsProps) => {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="purchasePrice">Valor de Compra (R$)</Label>
        <Input
          id="purchasePrice"
          type="number"
          placeholder="0,00"
          value={data.purchasePrice || ''}
          onChange={(e) => onDataChange('purchasePrice', Number(e.target.value))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="desiredMargin">Margem de Lucro Desejada (%)</Label>
        <Input
          id="desiredMargin"
          type="number"
          placeholder="30"
          value={data.desiredMargin || ''}
          onChange={(e) => onDataChange('desiredMargin', Number(e.target.value))}
        />
        <p className="text-xs text-gray-500">
          Esta é a margem de lucro final sobre o preço de venda
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="averagePrice">Preço Médio de Mercado</Label>
        <div className="relative">
          <Input
            id="averagePrice"
            type="number"
            placeholder={isLoading ? "Buscando..." : "0,00"}
            value={data.averagePrice || ''}
            readOnly
            className="bg-gray-50"
          />
          {isLoading && (
            <Loader2 className="w-4 h-4 absolute right-3 top-3 animate-spin" />
          )}
        </div>
      </div>
    </>
  );
};

export default PricingInputs;
