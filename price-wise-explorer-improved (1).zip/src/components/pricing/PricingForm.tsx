import React, { useEffect, useState } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MarketListing, PricingData } from "@/types/pricing";
import { findNCMSuggestions } from '@/utils/ncmData';
import { findSimilarListings } from '@/utils/marketData';
import MarketListings from './MarketListings';
import NCMCodeInput from './NCMCodeInput';
import LocationSelect from './LocationSelect';
import PricingInputs from './PricingInputs';
import { RefreshCw } from 'lucide-react';
import NCMFileUpload from './NCMFileUpload';

interface PricingFormProps {
  data: PricingData;
  onDataChange: (field: keyof PricingData, value: string | number | Array<{code: string, description: string}>) => void;
  marketListings: MarketListing[];
  isLoading?: boolean;
  onUpdateListings: () => void;
  onSaveSimulation?: () => void;
  onExportSimulation?: () => void;
}

const PricingForm = ({ 
  data, 
  onDataChange, 
  marketListings, 
  isLoading = false,
  onUpdateListings,
  onSaveSimulation,
  onExportSimulation 
}: PricingFormProps) => {
  useEffect(() => {
    const searchNCM = async () => {
      if (data.productName.length >= 2) {
        try {
          // Use the exact product name for NCM search
          const suggestions = await findNCMSuggestions(data.productName);
          const formattedSuggestions = suggestions.map(item => ({
            code: item.code,
            description: item.description
          }));
          
          onDataChange('ncmSuggestions', formattedSuggestions);
          
          if (suggestions.length > 0 && data.ncmCode === "") {
            onDataChange('ncmCode', `${suggestions[0].code} - ${suggestions[0].description}`);
          }
        } catch (error) {
          console.error("Error searching for NCM:", error);
        }
      }
    };
    
    searchNCM();
  }, [data.productName]);

  return (
    <div className="space-y-6">
      <Card className="p-6 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="productName">Nome do Produto</Label>
          <Input
            id="productName"
            placeholder="Digite nome ou descrição do produto"
            value={data.productName}
            onChange={(e) => onDataChange('productName', e.target.value)}
          />
          
          <div className="flex justify-end mt-2">
            <Button 
              onClick={onUpdateListings}
              type="button"
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
              disabled={isLoading || data.productName.length < 3}
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              Atualizar Preços
            </Button>
          </div>
        </div>

        <NCMCodeInput data={data} onDataChange={onDataChange} />
        <LocationSelect data={data} onDataChange={onDataChange} />
        <PricingInputs data={data} onDataChange={onDataChange} isLoading={isLoading} />
      </Card>

      <MarketListings listings={marketListings} isLoading={isLoading} />
      
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Ferramentas Adicionais</h3>
        <NCMFileUpload onNCMDataLoaded={data => onDataChange('ncmSuggestions', data)} />
      </Card>
    </div>
  );
};

export default PricingForm;
