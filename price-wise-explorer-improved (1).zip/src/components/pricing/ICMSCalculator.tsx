
import React, { useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Calculator } from "lucide-react";
import { ICMSBasicInputs } from './icms/ICMSBasicInputs';
import { ICMSOriginSelector } from './icms/ICMSOriginSelector';
import { ICMSResult } from './icms/ICMSResult';
import { useICMSCalculator } from '@/hooks/useICMSCalculator';

const ICMSCalculator = () => {
  const { inputs, result, updateInput, handleOriginStateChange, calculateICMS } = useICMSCalculator();

  useEffect(() => {
    calculateICMS();
  }, [inputs]);

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Calculator className="h-5 w-5 text-purple-600" />
        <h2 className="text-lg font-semibold">Cálculo de ICMS de Entrada</h2>
      </div>

      <ICMSBasicInputs 
        inputs={inputs} 
        onInputChange={updateInput} 
      />

      <ICMSOriginSelector 
        inputs={inputs}
        onOriginChange={(value) => updateInput('origin', value)}
        onStateChange={handleOriginStateChange}
      />

      <ICMSResult 
        result={result}
        merchandiseValue={inputs.merchandiseValue}
      />
    </Card>
  );
};

export default ICMSCalculator;
