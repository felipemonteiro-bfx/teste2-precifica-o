
import React from 'react';
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ICMSInputs } from "@/types/icms";

interface ICMSOriginSelectorProps {
  inputs: ICMSInputs;
  onOriginChange: (value: 'national' | 'imported') => void;
  onStateChange: (state: string) => void;
}

export const ICMSOriginSelector = ({ inputs, onOriginChange, onStateChange }: ICMSOriginSelectorProps) => {
  return (
    <div className="space-y-4">
      <div>
        <Label>Tipo de Origem</Label>
        <RadioGroup
          value={inputs.origin}
          onValueChange={onOriginChange}
          className="flex gap-4 mt-2"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="national" id="national" />
            <Label htmlFor="national">Nacional (outro estado)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="imported" id="imported" />
            <Label htmlFor="imported">Importado</Label>
          </div>
        </RadioGroup>
      </div>

      {inputs.origin === 'national' && (
        <div className="space-y-2">
          <Label htmlFor="originState">Estado de Origem</Label>
          <Select 
            value={inputs.originState} 
            onValueChange={onStateChange}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione o estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="SP">São Paulo</SelectItem>
              <SelectItem value="RJ">Rio de Janeiro</SelectItem>
              <SelectItem value="MG">Minas Gerais</SelectItem>
              <SelectItem value="AM">Amazonas</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="mt-4">
            <Label>Alíquota do Estado de Origem: {inputs.originRate}%</Label>
          </div>
        </div>
      )}

      <div className="space-y-2">
        <Label>Alíquota do Amazonas: {inputs.amRate}%</Label>
      </div>
    </div>
  );
};
