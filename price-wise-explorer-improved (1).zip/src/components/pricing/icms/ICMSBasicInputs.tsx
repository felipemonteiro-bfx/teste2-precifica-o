
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { ICMSInputs } from "@/types/icms";

interface ICMSBasicInputsProps {
  inputs: ICMSInputs;
  onInputChange: (field: keyof ICMSInputs, value: number) => void;
}

export const ICMSBasicInputs = ({ inputs, onInputChange }: ICMSBasicInputsProps) => {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="space-y-2">
        <Label htmlFor="merchandiseValue">Valor da Mercadoria (R$)*</Label>
        <Input
          id="merchandiseValue"
          type="number"
          value={inputs.merchandiseValue || ''}
          onChange={(e) => onInputChange('merchandiseValue', Number(e.target.value))}
          className={cn(
            inputs.merchandiseValue <= 0 && "border-red-500"
          )}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="ipi">IPI (R$)</Label>
        <Input
          id="ipi"
          type="number"
          value={inputs.ipi || ''}
          onChange={(e) => onInputChange('ipi', Number(e.target.value))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="freight">Frete (R$)</Label>
        <Input
          id="freight"
          type="number"
          value={inputs.freight || ''}
          onChange={(e) => onInputChange('freight', Number(e.target.value))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="insurance">Seguro (R$)</Label>
        <Input
          id="insurance"
          type="number"
          value={inputs.insurance || ''}
          onChange={(e) => onInputChange('insurance', Number(e.target.value))}
        />
      </div>
    </div>
  );
};
