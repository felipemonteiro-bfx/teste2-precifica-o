
import React from 'react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Check, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { ICMSCalculation } from "@/types/icms";

interface ICMSResultProps {
  result: ICMSCalculation;
  merchandiseValue: number;
}

export const ICMSResult = ({ result, merchandiseValue }: ICMSResultProps) => {
  if (!result.isValid) return null;

  return (
    <Alert className={cn(
      "mt-4",
      merchandiseValue > 0 ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
    )}>
      <div className="flex items-start gap-2">
        {merchandiseValue > 0 ? (
          <Check className="h-5 w-5 text-green-500 mt-0.5" />
        ) : (
          <Info className="h-5 w-5 text-red-500 mt-0.5" />
        )}
        <AlertDescription>
          <p className="font-medium text-lg">
            ICMS de Entrada Estimado: R$ {result.icmsValue.toFixed(2)}
          </p>
          <p className="text-sm mt-1">
            Base de cálculo: R$ {result.baseValue.toFixed(2)}
          </p>
          <p className="text-sm">
            Método: {result.method === 'interstate' ? 'Interestadual' : 'Importação'}
          </p>
        </AlertDescription>
      </div>
    </Alert>
  );
};
