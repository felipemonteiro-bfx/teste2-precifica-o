
import { Button } from "@/components/ui/button";
import { PricingData, PricingResults } from "@/types/pricing";
import ExportButton from './ExportButton';
import SaveSimulationButton from './SaveSimulationButton';
import { User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/sonner';

interface PricingActionsProps {
  data: PricingData;
  results: PricingResults;
  user: User | null;
  onUpdateListings: () => void;
}

const PricingActions = ({ data, results, user, onUpdateListings }: PricingActionsProps) => {
  const saveSimulation = async () => {
    if (!user) {
      toast.error("Você precisa estar logado para salvar simulações");
      return;
    }
    
    try {
      toast.info("Salvando simulação...");
      
      const { error } = await supabase
        .from('simulations')
        .insert({
          user_id: user.id,
          product_name: data.productName,
          ncm_code: data.ncmCode,
          purchase_price: data.purchasePrice,
          suggested_price: results.suggestedPrice,
          markup: results.markup,
          profit_margin: results.profitMargin
        });
      
      if (error) throw error;
      
      toast.success("Simulação salva com sucesso!");
    } catch (error) {
      console.error("Erro ao salvar simulação:", error);
      toast.error("Erro ao salvar simulação. Tente novamente.");
    }
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      {user && (
        <SaveSimulationButton onClick={saveSimulation} />
      )}
      <ExportButton data={data} results={results} />
    </div>
  );
};

export default PricingActions;
