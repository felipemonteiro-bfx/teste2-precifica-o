import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { FileJson, FileSpreadsheet } from 'lucide-react';
import { toast } from '@/components/ui/sonner';
import { NCMSuggestion } from '@/utils/marketplace/types';

interface NCMFileUploadProps {
  onNCMDataLoaded: (data: NCMSuggestion[]) => void;
}

const NCMFileUpload = ({ onNCMDataLoaded }: NCMFileUploadProps) => {
  const parseExcelFile = async (file: File) => {
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        if (!e.target?.result) return;
        
        // For now, we'll just parse CSV format for Excel files
        const text = e.target.result as string;
        const rows = text.split('\n');
        const headers = rows[0].split(',');
        
        const ncmData: NCMSuggestion[] = rows.slice(1)
          .filter(row => row.trim())
          .map(row => {
            const values = row.split(',');
            return {
              code: values[0]?.trim() || '',
              description: values[1]?.trim() || '',
              category: values[2]?.trim() || ''
            };
          });
        
        if (ncmData.length === 0) {
          toast.error('Nenhum dado NCM encontrado no arquivo');
          return;
        }
        
        onNCMDataLoaded(ncmData);
        toast.success(`${ncmData.length} códigos NCM importados com sucesso`);
      };
      
      reader.readAsText(file);
    } catch (error) {
      console.error('Erro ao processar arquivo Excel:', error);
      toast.error('Erro ao processar arquivo. Verifique o formato.');
    }
  };

  const parseJsonFile = async (file: File) => {
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        if (!e.target?.result) return;
        
        const jsonData = JSON.parse(e.target.result as string);
        if (!Array.isArray(jsonData)) {
          toast.error('O arquivo JSON deve conter um array de objetos NCM');
          return;
        }
        
        const ncmData: NCMSuggestion[] = jsonData.map(item => ({
          code: item.code || '',
          description: item.description || '',
          category: item.category || ''
        }));
        
        if (ncmData.length === 0) {
          toast.error('Nenhum dado NCM encontrado no arquivo');
          return;
        }
        
        onNCMDataLoaded(ncmData);
        toast.success(`${ncmData.length} códigos NCM importados com sucesso`);
      };
      
      reader.readAsText(file);
    } catch (error) {
      console.error('Erro ao processar arquivo JSON:', error);
      toast.error('Erro ao processar arquivo. Verifique o formato JSON.');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const fileType = file.name.split('.').pop()?.toLowerCase();
    
    if (fileType === 'json') {
      await parseJsonFile(file);
    } else if (fileType === 'csv' || fileType === 'xlsx' || fileType === 'xls') {
      await parseExcelFile(file);
    } else {
      toast.error('Formato de arquivo não suportado. Use .json, .csv, .xlsx ou .xls');
    }
  };

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Importar dados NCM</h3>
      
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <Input
            type="file"
            accept=".json,.csv,.xlsx,.xls"
            onChange={handleFileUpload}
            className="hidden"
            id="ncm-file"
          />
          
          <div className="grid grid-cols-2 gap-4 w-full">
            <Button
              variant="outline"
              onClick={() => document.getElementById('ncm-file')?.click()}
              className="flex items-center gap-2"
            >
              <FileJson className="w-4 h-4" />
              Importar JSON
            </Button>
            
            <Button
              variant="outline"
              onClick={() => document.getElementById('ncm-file')?.click()}
              className="flex items-center gap-2"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Importar Excel
            </Button>
          </div>
        </div>
        
        <p className="text-sm text-gray-500">
          Formatos suportados: JSON, CSV, XLSX, XLS
        </p>
      </div>
    </Card>
  );
};

export default NCMFileUpload;
