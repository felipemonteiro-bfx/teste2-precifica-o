
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PricingData } from "@/types/pricing";

interface LocationSelectProps {
  data: Pick<PricingData, 'origin'>;
  onDataChange: (field: keyof PricingData, value: string) => void;
}

const originStates = [
  { value: 'AM', label: 'Amazonas (AM)' },
  { value: 'SP', label: 'São Paulo (SP)' },
  { value: 'RJ', label: 'Rio de Janeiro (RJ)' },
  { value: 'MG', label: 'Minas Gerais (MG)' },
  { value: 'PR', label: 'Paraná (PR)' },
  { value: 'RS', label: 'Rio Grande do Sul (RS)' },
  { value: 'SC', label: 'Santa Catarina (SC)' },
  { value: 'BA', label: 'Bahia (BA)' },
  { value: 'DF', label: 'Distrito Federal (DF)' },
];

const LocationSelect = ({ data, onDataChange }: LocationSelectProps) => {
  return (
    <div className="space-y-2">
      <Label>Estado de Origem</Label>
      <Select
        value={data.origin || 'AM'}
        onValueChange={(value: string) => onDataChange('origin', value)}
      >
        <SelectTrigger>
          <SelectValue placeholder="Selecione o estado de origem" />
        </SelectTrigger>
        <SelectContent>
          {originStates.map(state => (
            <SelectItem key={state.value} value={state.value}>{state.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <p className="text-xs text-gray-500">
        Estado de destino padrão: Amazonas (AM)
      </p>
    </div>
  );
};

export default LocationSelect;

