
import React from "react";
import { Card } from "@/components/ui/card";
import { MarketListing } from "@/types/pricing";
import { formatCurrency } from "@/utils/pricingCalculations";
import { ExternalLink, ShoppingCart, Store } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MarketListingsProps {
  listings: MarketListing[];
  isLoading: boolean;
}

const MarketListings = ({ listings, isLoading }: MarketListingsProps) => {
  if (listings.length === 0 && !isLoading) return null;

  const handleOpenLink = (url: string) => {
    // Use window.open with _blank target and noopener for security
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card className="p-4 space-y-3 bg-white">
      <div className="flex items-center gap-2 text-purple-800">
        <ShoppingCart className="h-5 w-5" />
        <h3 className="font-semibold text-lg">Ofertas encontradas</h3>
      </div>
      
      {isLoading ? (
        <div className="p-8 text-center">
          <div className="animate-spin w-10 h-10 border-4 border-purple-400 border-t-transparent rounded-full mx-auto"></div>
          <p className="text-gray-500 mt-4">Buscando ofertas em tempo real...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {listings.map((listing) => (
            <div key={listing.id} className="flex flex-col bg-gray-50 rounded overflow-hidden border border-gray-100 hover:shadow-md transition-shadow">
              {listing.imageUrl ? (
                <div className="h-40 overflow-hidden bg-white flex items-center justify-center">
                  <img 
                    src={listing.imageUrl} 
                    alt={listing.title} 
                    className="object-contain w-full h-full p-2"
                    onError={(e) => {
                      // Fallback for broken images
                      (e.target as HTMLImageElement).src = 'https://placehold.co/400x300/purple/white?text=Produto';
                    }}
                  />
                </div>
              ) : (
                <div className="h-40 bg-gray-100 flex items-center justify-center">
                  <Store className="h-12 w-12 text-gray-400" />
                </div>
              )}
              <div className="p-3 space-y-2 flex-1 flex flex-col">
                <h4 className="font-medium text-sm line-clamp-2 flex-1">{listing.title}</h4>
                <p className="font-bold text-lg text-purple-700">{formatCurrency(listing.price)}</p>
                {listing.source && (
                  <p className="text-xs text-gray-500 flex items-center gap-1">
                    <Store className="h-3 w-3" /> 
                    {listing.source}
                  </p>
                )}
                {listing.link && listing.link !== '#' ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full flex items-center justify-center gap-1 text-blue-600 hover:text-blue-800 mt-auto"
                    onClick={() => handleOpenLink(listing.link)}
                  >
                    Ver anúncio <ExternalLink className="h-3 w-3" />
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full flex items-center justify-center gap-1 text-blue-600 hover:text-blue-800 mt-auto"
                    onClick={() => handleOpenLink(`https://www.google.com/search?q=${encodeURIComponent(listing.title)}`)}
                  >
                    Buscar produto <ExternalLink className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};

export default MarketListings;
