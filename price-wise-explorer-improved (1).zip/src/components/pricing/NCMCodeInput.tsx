import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { PricingData } from "@/types/pricing";
import { Loader2 } from "lucide-react";
import NCMFileUpload from './NCMFileUpload';
import { NCMSuggestion } from '@/utils/marketplace/types';

interface NCMCodeInputProps {
  data: Pick<PricingData, 'ncmCode' | 'ncmSuggestions' | 'productName'>;
  onDataChange: (field: keyof PricingData, value: string | Array<{code: string, description: string}>) => void;
}

const NCMCodeInput = ({ data, onDataChange }: NCMCodeInputProps) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSelectNCM = (code: string, description: string) => {
    onDataChange('ncmCode', `${code} - ${description}`);
    setShowSuggestions(false);
  };

  const handleNCMDataLoaded = (ncmData: NCMSuggestion[]) => {
    const suggestions = ncmData.map(item => ({
      code: item.code,
      description: item.description
    }));
    onDataChange('ncmSuggestions', suggestions);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="ncmCode">Código NCM</Label>
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Input
              id="ncmCode"
              placeholder="Selecione um NCM das sugestões"
              value={data.ncmCode}
              className="bg-gray-50 pr-24"
              readOnly
            />
            
            <Popover open={showSuggestions} onOpenChange={setShowSuggestions}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  type="button"
                  size="sm"
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 z-10"
                  onClick={() => setShowSuggestions(!showSuggestions)}
                >
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : showSuggestions ? "Fechar" : "Ver NCMs"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[300px] p-0 bg-white z-50" align="start">
                <div className="max-h-[200px] overflow-y-auto p-1">
                  {isLoading ? (
                    <div className="p-4 text-center">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                      <p className="text-sm text-gray-500 mt-2">Buscando NCMs...</p>
                    </div>
                  ) : data.ncmSuggestions.length > 0 ? (
                    <div className="space-y-1">
                      {data.ncmSuggestions.map((suggestion) => (
                        <div 
                          key={suggestion.code}
                          className="p-2 hover:bg-gray-100 rounded cursor-pointer text-sm"
                          onClick={() => handleSelectNCM(suggestion.code, suggestion.description)}
                        >
                          <div className="font-semibold">{suggestion.code}</div>
                          <div className="text-gray-600">{suggestion.description}</div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-2 text-center text-gray-500">
                      {data.productName.length < 2 
                        ? "Digite o nome do produto" 
                        : "Nenhuma sugestão encontrada"}
                    </div>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>
      {data.ncmSuggestions.length > 0 && !isLoading && (
        <p className="text-xs text-gray-500 mt-1">
          {data.ncmSuggestions.length} sugestões encontradas
        </p>
      )}
      <NCMFileUpload onNCMDataLoaded={handleNCMDataLoaded} />
    </div>
  );
};

export default NCMCodeInput;
