
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { PricingData, PricingResults } from "@/types/pricing";
import { formatCurrency, formatPercentage } from "@/utils/pricingCalculations";
import { ArrowDown, ArrowUp, MinusIcon } from "lucide-react";
import ExportButton from "./ExportButton";

interface PricingResultsPanelProps {
  data: PricingData;
  results: PricingResults;
  onDataChange?: (field: keyof PricingData, value: number) => void;
}

const PricingResultsPanel = ({ data, results, onDataChange }: PricingResultsPanelProps) => {
  const renderPriceDifference = () => {
    if (!data.averagePrice || data.averagePrice <= 0) return null;
    
    const percentDiff = ((results.suggestedPrice - data.averagePrice) / data.averagePrice) * 100;
    
    let icon = <MinusIcon className="h-4 w-4" />;
    let colorClass = "text-gray-700";
    
    if (percentDiff > 5) {
      icon = <ArrowUp className="h-4 w-4 text-red-500" />;
      colorClass = "text-red-600";
    } else if (percentDiff < -5) {
      icon = <ArrowDown className="h-4 w-4 text-green-500" />;
      colorClass = "text-green-600";
    }
    
    return (
      <div className="flex items-center mt-1 text-sm">
        {icon}
        <span className={`ml-1 ${colorClass}`}>
          {percentDiff > 0 ? '+' : ''}{formatPercentage(percentDiff)} vs. média do mercado
        </span>
      </div>
    );
  };

  return (
    <Card className="p-6 space-y-4 bg-purple-50">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-purple-800">Resultados</h2>
        <ExportButton data={data} results={results} />
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm">
        <Label className="text-sm text-gray-600">Markup</Label>
        <p className="text-lg font-semibold">{formatPercentage(results.markup)}</p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm">
        <Label className="text-sm text-gray-600">Margem de Lucro</Label>
        <p className="text-lg font-semibold">{formatPercentage(results.profitMargin)}</p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm">
        <Label className="text-sm text-gray-600">Preço de Venda</Label>
        <Input
          type="number"
          value={results.suggestedPrice || ''}
          onChange={(e) => onDataChange?.('customPrice', Number(e.target.value))}
          className="text-xl font-bold text-purple-600 mt-1"
          placeholder={formatCurrency(results.suggestedPrice)}
        />
        <p className="text-xs text-gray-500 mt-1">
          Preço sugerido: {formatCurrency(results.suggestedPrice)}
        </p>
        {data.averagePrice > 0 && renderPriceDifference()}
      </div>
      
      {data.averagePrice > 0 && (
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <Label className="text-sm text-gray-600">Preço Médio do Mercado</Label>
          <p className="text-lg font-semibold">{formatCurrency(data.averagePrice)}</p>
          <p className="text-xs text-gray-500">Baseado em produtos similares em {data.state}</p>
        </div>
      )}
    </Card>
  );
};

export default PricingResultsPanel;
