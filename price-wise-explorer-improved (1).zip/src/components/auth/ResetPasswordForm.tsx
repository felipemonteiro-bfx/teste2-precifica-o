
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Send } from "lucide-react";

interface ResetPasswordFormProps {
  onSubmit: (email: string) => void;
  onCancel: () => void;
}

export const ResetPasswordForm = ({ onSubmit, onCancel }: ResetPasswordFormProps) => {
  const [email, setEmail] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onSubmit(email);
    }
  };
  
  return (
    <Card className="w-full max-w-md p-6 mx-auto">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-purple-600">Recuperar Senha</h1>
        <p className="text-gray-600 mt-2">
          Digite seu e-mail para receber um link de recuperação
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="reset-email">Email</Label>
          <Input
            id="reset-email"
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-purple-600 hover:bg-purple-700 flex items-center justify-center gap-2"
        >
          <Send size={16} />
          Enviar link de recuperação
        </Button>
        
        <Button 
          type="button"
          variant="outline"
          className="w-full mt-2 flex items-center justify-center gap-2"
          onClick={onCancel}
        >
          <ArrowLeft size={16} />
          Voltar ao login
        </Button>
      </form>
    </Card>
  );
};
