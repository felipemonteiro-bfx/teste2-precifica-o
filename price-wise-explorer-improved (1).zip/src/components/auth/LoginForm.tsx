
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { toast } from "@/components/ui/sonner";
import { useAuth } from "@/contexts/AuthContext";
import EmailForm from "./login/EmailForm";
import GoogleButton from "./login/GoogleButton";
import FormActions from "./login/FormActions";
import { formStyles } from "@/lib/styles";

interface LoginFormProps {
  onForgotPassword: () => void;
}

const LoginForm = ({ onForgotPassword }: LoginFormProps) => {
  const { signIn, signInWithGoogle, signUp } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isNewUser, setIsNewUser] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      console.log("Iniciando processo de autenticação", { isNewUser, email });
      
      if (isNewUser) {
        if (password !== confirmPassword) {
          toast.error("As senhas não coincidem!");
          setLoading(false);
          return;
        }
        
        const { error } = await signUp(email, password);
        if (error) {
          console.error("Erro no signup:", error);
          throw error;
        }
        
        toast.success("Conta criada! Verifique seu e-mail para confirmar o cadastro.");
      } else {
        console.log("Tentando fazer login");
        const { error } = await signIn(email, password);
        if (error) {
          console.error("Erro no login:", error);
          throw error;
        }
        
        toast.success("Login realizado com sucesso!");
      }
    } catch (error: any) {
      console.error("Erro completo:", error);
      
      const errorMessage = error.message || "Erro ao realizar operação";
      let translatedError = errorMessage;
      
      if (errorMessage.includes("Invalid login credentials")) {
        translatedError = "Email ou senha incorretos";
      } else if (errorMessage.includes("Email not confirmed")) {
        translatedError = "Email não confirmado. Verifique sua caixa de entrada";
      } else if (errorMessage.includes("already registered")) {
        translatedError = "Email já cadastrado. Tente fazer login";
      }
      
      toast.error(translatedError);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      console.log("Iniciando login com Google");
      const { error } = await signInWithGoogle();
      if (error) {
        console.error("Erro no login com Google:", error);
        throw error;
      }
    } catch (error: any) {
      console.error("Erro completo Google:", error);
      toast.error("Erro ao realizar login com Google");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className={formStyles.card}>
      <div className="text-center mb-6">
        <h1 className={formStyles.title}>CalculeX</h1>
        <p className={formStyles.subtitle}>Calculadora de Precificação Inteligente</p>
      </div>

      <form onSubmit={handleSubmit} className={formStyles.form}>
        <EmailForm
          email={email}
          password={password}
          confirmPassword={confirmPassword}
          loading={loading}
          isNewUser={isNewUser}
          onEmailChange={(e) => setEmail(e.target.value)}
          onPasswordChange={(e) => setPassword(e.target.value)}
          onConfirmPasswordChange={(e) => setConfirmPassword(e.target.value)}
        />

        <div className={formStyles.divider.wrapper}>
          <div className={formStyles.divider.line}>
            <span className={formStyles.divider.span} />
          </div>
          <div className={formStyles.divider.text}>
            <span className={formStyles.divider.label}>Ou continue com</span>
          </div>
        </div>

        <GoogleButton loading={loading} onGoogleSignIn={handleGoogleSignIn} />
      </form>

      <FormActions
        isNewUser={isNewUser}
        loading={loading}
        onToggleNewUser={() => setIsNewUser(!isNewUser)}
        onForgotPassword={onForgotPassword}
      />
    </Card>
  );
};

export default LoginForm;
