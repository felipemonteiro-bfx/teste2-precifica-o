
import { formStyles } from "@/lib/styles";

interface FormActionsProps {
  isNewUser: boolean;
  loading: boolean;
  onToggleNewUser: () => void;
  onForgotPassword: () => void;
}

const FormActions = ({ 
  isNewUser, 
  loading, 
  onToggleNewUser, 
  onForgotPassword 
}: FormActionsProps) => {
  return (
    <div className={formStyles.actionButtons}>
      <button
        type="button"
        onClick={onToggleNewUser}
        className={formStyles.link}
        disabled={loading}
      >
        {isNewUser ? "Já tenho uma conta" : "Primeiro acesso"}
      </button>

      {!isNewUser && (
        <button
          type="button"
          onClick={onForgotPassword}
          className={formStyles.link}
          disabled={loading}
        >
          Esqueci a senha
        </button>
      )}
    </div>
  );
};

export default FormActions;
