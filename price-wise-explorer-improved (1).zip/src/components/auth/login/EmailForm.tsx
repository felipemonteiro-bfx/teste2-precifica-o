
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { formStyles, buttonStyles } from "@/lib/styles";

interface EmailFormProps {
  email: string;
  password: string;
  confirmPassword: string;
  loading: boolean;
  isNewUser: boolean;
  onEmailChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onPasswordChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onConfirmPasswordChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const EmailForm = ({
  email,
  password,
  confirmPassword,
  loading,
  isNewUser,
  onEmailChange,
  onPasswordChange,
  onConfirmPasswordChange,
}: EmailFormProps) => {
  return (
    <>
      <div className={formStyles.inputGroup}>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          placeholder="seu@email.com"
          value={email}
          onChange={onEmailChange}
          required
          disabled={loading}
        />
      </div>

      <div className={formStyles.inputGroup}>
        <Label htmlFor="password">Senha</Label>
        <Input
          id="password"
          type="password"
          placeholder="********"
          value={password}
          onChange={onPasswordChange}
          required
          disabled={loading}
        />
      </div>

      {isNewUser && (
        <div className={formStyles.inputGroup}>
          <Label htmlFor="confirmPassword">Confirmar Senha</Label>
          <Input
            id="confirmPassword"
            type="password"
            placeholder="********"
            value={confirmPassword}
            onChange={onConfirmPasswordChange}
            required
            disabled={loading}
          />
        </div>
      )}

      <Button 
        type="submit" 
        className={buttonStyles.primary}
        disabled={loading}
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {isNewUser ? "Criando conta..." : "Entrando..."}
          </>
        ) : isNewUser ? "Criar Conta" : "Entrar"}
      </Button>
    </>
  );
};

export default EmailForm;
