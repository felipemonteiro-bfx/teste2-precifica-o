
import React from 'react';
import { usePricingCalculator } from '@/hooks/usePricingCalculator';
import PricingForm from './pricing/PricingForm';
import PricingResultsPanel from './pricing/PricingResults';
import ICMSCalculator from './pricing/ICMSCalculator';
import Footer from './Footer';
import { useAuth } from '@/contexts/AuthContext';
import PricingActions from './pricing/PricingActions';

const PricingCalculator = () => {
  const { user } = useAuth();
  const {
    data,
    results,
    marketListings,
    isLoading,
    handleInputChange,
    fetchMarketListings
  } = usePricingCalculator();

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-600">
        CalculeX - Calculadora de Precificação
      </h1>

      <div className="grid gap-6">
        <ICMSCalculator />
        
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <PricingForm 
              data={data} 
              onDataChange={handleInputChange}
              marketListings={marketListings}
              isLoading={isLoading}
              onUpdateListings={fetchMarketListings}
            />
          </div>
          <div className="space-y-6">
            <PricingResultsPanel data={data} results={results} />
            <PricingActions 
              data={data}
              results={results}
              user={user}
              onUpdateListings={fetchMarketListings}
            />
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default PricingCalculator;
