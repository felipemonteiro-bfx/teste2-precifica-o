
import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const phoneNumber = "92993276765";
  const email = "felipe.monteiro@softlive.com.br";

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 mt-12 py-8 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-purple-600 mb-4">CalculeX</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Calculadora de precificação para ajudar a otimizar seus preços e aumentar seus lucros.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-purple-600 mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400">Home</a></li>
              <li><a href="/about" className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400">Sobre</a></li>
              <li><a href="/pricing" className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400">Preços</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-purple-600 mb-4">Fale Conosco</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <Phone size={20} className="mr-3 text-purple-500" />
                <span className="text-gray-600 dark:text-gray-400">{phoneNumber}</span>
              </div>
              <div className="flex items-center">
                <Mail size={20} className="mr-3 text-purple-500" />
                <span className="text-gray-600 dark:text-gray-400">{email}</span>
              </div>
              <div className="flex items-center">
                <MapPin size={20} className="mr-3 text-purple-500" />
                <span className="text-gray-600 dark:text-gray-400">Manaus, AM - Brasil</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800 text-center text-gray-500 dark:text-gray-400">
          <p>© {new Date().getFullYear()} CalculeX. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
