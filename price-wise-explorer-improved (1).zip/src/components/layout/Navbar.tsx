
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { User, LogOut } from "lucide-react";

interface NavbarProps {
  isAuthenticated: boolean;
  userEmail?: string;
  onLogout: () => void;
}

const Navbar = ({ isAuthenticated, userEmail, onLogout }: NavbarProps) => {
  const navigate = useNavigate();

  return (
    <nav className="bg-white shadow-sm py-3 px-4">
      <div className="container mx-auto max-w-4xl flex justify-between items-center">
        <div className="flex items-center">
          <span className="text-xl font-bold text-purple-600">CalculeX</span>
        </div>

        {isAuthenticated ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center text-sm text-gray-600">
              <User size={16} className="mr-1" />
              <span className="hidden sm:inline">{userEmail}</span>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center text-gray-700" 
              onClick={onLogout}
            >
              <LogOut size={16} className="mr-1" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        ) : (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-purple-600" 
            onClick={() => navigate("/login")}
          >
            Login
          </Button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
