
import React from 'react';
import { Phone, Mail } from 'lucide-react';

const ContactInfo = () => {
  const phoneNumber = "92993276765";
  const email = "felipe.monteiro@softlive.com.br";

  return (
    <div className="bg-white shadow-md rounded-lg p-6 mt-4">
      <h2 className="text-xl font-bold text-purple-600 mb-4">Fale Conosco</h2>
      <div className="space-y-3">
        <div className="flex items-center">
          <Phone size={20} className="mr-3 text-purple-500" />
          <span>{phoneNumber}</span>
        </div>
        <div className="flex items-center">
          <Mail size={20} className="mr-3 text-purple-500" />
          <span>{email}</span>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;
