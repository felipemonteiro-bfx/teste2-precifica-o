
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from '@/components/ui/sonner';
import { CreditCard, BarChart4, QrCode } from 'lucide-react';

interface PaymentMethod {
  id: string;
  type: 'credit-card' | 'pix';
  name: string;
  last4?: string;
  expiry?: string;
  default: boolean;
}

const PaymentProfile = () => {
  const [activeTab, setActiveTab] = useState('credit-card');
  const [loading, setLoading] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'credit-card',
      name: 'Cartão principal',
      last4: '4242',
      expiry: '12/25',
      default: true
    }
  ]);
  
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardName: '',
    expiry: '',
    cvc: '',
    pixKey: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCreditCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const newPaymentMethod: PaymentMethod = {
        id: Date.now().toString(),
        type: 'credit-card',
        name: formData.cardName,
        last4: formData.cardNumber.slice(-4),
        expiry: formData.expiry,
        default: false
      };
      
      setPaymentMethods(prev => [...prev, newPaymentMethod]);
      
      // Reset form
      setFormData({
        cardNumber: '',
        cardName: '',
        expiry: '',
        cvc: '',
        pixKey: ''
      });
      
      setLoading(false);
      toast.success('Cartão adicionado com sucesso!');
    }, 1500);
  };

  const handlePixSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const newPaymentMethod: PaymentMethod = {
        id: Date.now().toString(),
        type: 'pix',
        name: `Chave PIX: ${formData.pixKey.substring(0, 5)}...`,
        default: false
      };
      
      setPaymentMethods(prev => [...prev, newPaymentMethod]);
      
      // Reset form
      setFormData({
        cardNumber: '',
        cardName: '',
        expiry: '',
        cvc: '',
        pixKey: ''
      });
      
      setLoading(false);
      toast.success('Chave PIX adicionada com sucesso!');
    }, 1500);
  };

  const setDefaultPaymentMethod = (id: string) => {
    setPaymentMethods(methods => 
      methods.map(method => ({
        ...method,
        default: method.id === id
      }))
    );
    toast.success('Método de pagamento padrão atualizado');
  };

  const removePaymentMethod = (id: string) => {
    setPaymentMethods(methods => methods.filter(method => method.id !== id));
    toast.success('Método de pagamento removido');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl flex items-center gap-2">
          <BarChart4 className="h-5 w-5 text-purple-600" />
          Perfil de Pagamento
        </CardTitle>
        <CardDescription>
          Gerencie seus métodos de pagamento para faturamento recorrente
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="credit-card" onValueChange={setActiveTab} value={activeTab}>
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="credit-card" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Cartão de Crédito
            </TabsTrigger>
            <TabsTrigger value="pix" className="flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              PIX
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="credit-card">
            <form onSubmit={handleCreditCardSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cardName">Nome no Cartão</Label>
                <Input 
                  id="cardName" 
                  name="cardName"
                  value={formData.cardName}
                  onChange={handleInputChange}
                  placeholder="Nome como aparece no cartão" 
                  required 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cardNumber">Número do Cartão</Label>
                <Input 
                  id="cardNumber" 
                  name="cardNumber"
                  value={formData.cardNumber}
                  onChange={handleInputChange}
                  placeholder="1234 5678 9012 3456" 
                  required 
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Validade</Label>
                  <Input 
                    id="expiry" 
                    name="expiry"
                    value={formData.expiry}
                    onChange={handleInputChange}
                    placeholder="MM/AA" 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvc">CVC</Label>
                  <Input 
                    id="cvc" 
                    name="cvc"
                    value={formData.cvc}
                    onChange={handleInputChange}
                    placeholder="123" 
                    required 
                  />
                </div>
              </div>
              
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Processando...' : 'Adicionar Cartão'}
              </Button>
            </form>
          </TabsContent>
          
          <TabsContent value="pix">
            <form onSubmit={handlePixSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pixKey">Chave PIX</Label>
                <Input 
                  id="pixKey" 
                  name="pixKey"
                  value={formData.pixKey}
                  onChange={handleInputChange}
                  placeholder="CPF, E-mail, Telefone ou Chave Aleatória" 
                  required 
                />
              </div>
              
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Processando...' : 'Adicionar Chave PIX'}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
        
        {paymentMethods.length > 0 && (
          <div className="space-y-4 mt-8">
            <h3 className="font-medium text-lg">Métodos de Pagamento Salvos</h3>
            <div className="space-y-3">
              {paymentMethods.map(method => (
                <div 
                  key={method.id} 
                  className={`p-3 rounded-lg border ${method.default ? 'border-purple-500 bg-purple-50' : 'border-gray-200'} flex justify-between items-center`}
                >
                  <div className="flex items-center gap-3">
                    {method.type === 'credit-card' ? (
                      <CreditCard className="h-5 w-5 text-gray-600" />
                    ) : (
                      <QrCode className="h-5 w-5 text-gray-600" />
                    )}
                    <div>
                      <p className="font-medium">{method.name}</p>
                      {method.type === 'credit-card' && (
                        <p className="text-sm text-gray-500">
                          **** **** **** {method.last4} • Expira em {method.expiry}
                        </p>
                      )}
                      {method.default && (
                        <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full">
                          Padrão
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {!method.default && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setDefaultPaymentMethod(method.id)}
                      >
                        Definir como padrão
                      </Button>
                    )}
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => removePaymentMethod(method.id)}
                    >
                      Remover
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between text-sm text-gray-500">
        <p>Seus dados de pagamento são armazenados com segurança</p>
      </CardFooter>
    </Card>
  );
};

export default PaymentProfile;
