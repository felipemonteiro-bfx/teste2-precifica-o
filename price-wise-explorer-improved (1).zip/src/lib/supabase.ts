import { createClient } from '@supabase/supabase-js';

// Usar variáveis de ambiente para as credenciais do Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Configuração aprimorada para persistência de sessão
const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    flowType: 'implicit',
  }
});

// Configurar o tempo de expiração da sessão para 30 dias (em segundos)
const SESSION_EXPIRY_SECONDS = 30 * 24 * 60 * 60;

// Função para verificar e renovar o token se necessário
export const checkAndRefreshSession = async () => {
  try {
    const { data } = await supabase.auth.getSession();
    const session = data.session;
    
    if (session) {
      // Se a sessão existir mas estiver próxima de expirar (menos de 1 dia), renovar
      const expiresAt = session.expires_at;
      const now = Math.floor(Date.now() / 1000);
      const oneDayInSeconds = 24 * 60 * 60;
      
      if (expiresAt && (expiresAt - now < oneDayInSeconds)) {
        console.log('Sessão próxima de expirar, renovando...');
        await supabase.auth.refreshSession();
        console.log('Sessão renovada com sucesso');
      }
    }
  } catch (error) {
    console.error('Erro ao verificar/renovar sessão:', error);
  }
};

// Função para salvar a sessão em cookies para persistência adicional
export const saveSessionToCookies = (session: any) => {
  if (!session) return;
  
  try {
    // Salvar token de acesso em cookie com expiração de 30 dias
    document.cookie = `sb-access-token=${session.access_token}; max-age=${SESSION_EXPIRY_SECONDS}; path=/; SameSite=Lax`;
    
    // Salvar token de refresh em cookie com expiração de 30 dias
    document.cookie = `sb-refresh-token=${session.refresh_token}; max-age=${SESSION_EXPIRY_SECONDS}; path=/; SameSite=Lax`;
    
    console.log('Sessão salva em cookies para persistência adicional');
  } catch (error) {
    console.error('Erro ao salvar sessão em cookies:', error);
  }
};

// Função para recuperar a sessão dos cookies
export const getSessionFromCookies = () => {
  try {
    const cookies = document.cookie.split(';').reduce((acc, cookie) => {
      const [key, value] = cookie.trim().split('=');
      acc[key] = value;
      return acc;
    }, {} as Record<string, string>);
    
    const accessToken = cookies['sb-access-token'];
    const refreshToken = cookies['sb-refresh-token'];
    
    if (accessToken && refreshToken) {
      console.log('Sessão recuperada dos cookies');
      return { access_token: accessToken, refresh_token: refreshToken };
    }
    
    return null;
  } catch (error) {
    console.error('Erro ao recuperar sessão dos cookies:', error);
    return null;
  }
};

console.info('Conectado ao Supabase com persistência de sessão aprimorada');

export { supabase };
