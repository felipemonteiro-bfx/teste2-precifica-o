
import { cn } from "./utils";

export const formStyles = {
  card: "w-full max-w-md p-6 mx-auto",
  title: "text-3xl font-bold text-purple-600",
  subtitle: "text-gray-600 mt-2",
  form: "space-y-4",
  divider: {
    wrapper: "relative my-4",
    line: "absolute inset-0 flex items-center",
    span: "w-full border-t",
    text: "relative flex justify-center text-xs uppercase",
    label: "bg-white px-2 text-gray-500"
  },
  inputGroup: "space-y-2",
  link: "text-sm text-purple-600 hover:underline",
  actionButtons: "mt-4 flex justify-between items-center"
};

export const buttonStyles = {
  primary: cn(
    "w-full bg-purple-600 hover:bg-purple-700",
    "text-white font-medium rounded-md"
  ),
  outline: "w-full"
};
