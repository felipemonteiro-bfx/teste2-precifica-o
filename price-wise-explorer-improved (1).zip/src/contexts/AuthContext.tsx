import { createContext, useContext, useEffect, useState } from 'react';
import { User, AuthError, OAuthResponse, AuthResponse } from '@supabase/supabase-js';
import { supabase, checkAndRefreshSession, saveSessionToCookies, getSessionFromCookies } from '@/lib/supabase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<AuthResponse>;
  signInWithGoogle: () => Promise<OAuthResponse>;
  signUp: (email: string, password: string) => Promise<AuthResponse>;
  signOut: () => Promise<{ error: AuthError | null }>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Função para tentar restaurar a sessão dos cookies se o localStorage falhar
  const tryRestoreSession = async () => {
    try {
      // Primeiro tenta obter a sessão normalmente
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        setUser(session.user);
        // Salva a sessão em cookies para persistência adicional
        saveSessionToCookies(session);
        return true;
      }
      
      // Se não houver sessão no localStorage, tenta recuperar dos cookies
      const cookieSession = getSessionFromCookies();
      if (cookieSession) {
        // Tenta restaurar a sessão usando os tokens dos cookies
        const { data, error } = await supabase.auth.setSession({
          access_token: cookieSession.access_token,
          refresh_token: cookieSession.refresh_token
        });
        
        if (data.session && !error) {
          setUser(data.session.user);
          console.log('Sessão restaurada com sucesso dos cookies');
          return true;
        }
      }
      
      return false;
    } catch (error) {
      console.error('Erro ao tentar restaurar sessão:', error);
      return false;
    }
  };

  useEffect(() => {
    // Inicialização com verificação de sessão aprimorada
    const initAuth = async () => {
      setLoading(true);
      
      // Tenta restaurar a sessão
      const restored = await tryRestoreSession();
      
      if (!restored) {
        setUser(null);
      }
      
      // Verifica e renova a sessão se necessário
      await checkAndRefreshSession();
      
      setLoading(false);
    };
    
    initAuth();

    // Escuta mudanças na autenticação
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log(`Evento de autenticação: ${event}`);
      
      if (session) {
        setUser(session.user);
        // Salva a sessão em cookies para persistência adicional
        saveSessionToCookies(session);
      } else {
        setUser(null);
      }
    });

    // Configura verificação periódica da sessão (a cada 15 minutos)
    const sessionCheckInterval = setInterval(() => {
      checkAndRefreshSession();
    }, 15 * 60 * 1000);

    return () => {
      subscription.unsubscribe();
      clearInterval(sessionCheckInterval);
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const response = await supabase.auth.signInWithPassword({ 
      email, 
      password,
      options: {
        // Aumenta o tempo de expiração da sessão para 30 dias
        expiresIn: 30 * 24 * 60 * 60
      }
    });
    
    if (response.data.session) {
      // Salva a sessão em cookies para persistência adicional
      saveSessionToCookies(response.data.session);
    }
    
    return response;
  };

  const signInWithGoogle = async () => {
    return supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin,
        // Aumenta o tempo de expiração da sessão para 30 dias
        expiresIn: 30 * 24 * 60 * 60
      }
    });
  };

  const signUp = async (email: string, password: string) => {
    const response = await supabase.auth.signUp({ 
      email, 
      password,
      options: {
        // Aumenta o tempo de expiração da sessão para 30 dias
        expiresIn: 30 * 24 * 60 * 60
      }
    });
    
    if (response.data.session) {
      // Salva a sessão em cookies para persistência adicional
      saveSessionToCookies(response.data.session);
    }
    
    return response;
  };

  const signOut = async () => {
    // Limpa os cookies de sessão
    document.cookie = 'sb-access-token=; max-age=0; path=/; SameSite=Lax';
    document.cookie = 'sb-refresh-token=; max-age=0; path=/; SameSite=Lax';
    
    // Faz logout no Supabase
    return supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signInWithGoogle, signUp, signOut }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
