
export interface PricingData {
  productName: string;
  ncmCode: string;
  ncmSuggestions: Array<{code: string, description: string}>;
  origin: string; // Changed from 'local' | 'other-state' to string to accept state codes
  purchasePrice: number;
  customPrice?: number;
  city: string;
  state: string;
  importTax: number;
  desiredMargin: number;
  averagePrice: number;
  id?: string | number;
  createdAt?: string;
}

export interface PricingResults {
  priceWithTaxes: number;
  markup: number;
  profitMargin: number;
  suggestedPrice: number;
  priceDifference?: number;
}

export interface MarketListing {
  id: string;
  title: string;
  price: number;
  source?: string;
  imageUrl?: string;
  link?: string;
  seller?: string;
  state?: string;
  relevance?: number;
}

export interface NCMTaxInfo {
  code: string;
  description: string;
  baseRate: number;
  interstate: number;
}

export interface NCMItem {
  name: string;
  code: string;
  description: string;
  baseRate: number;
  interstate: number;
}

export interface SimulationRecord {
  id: number;
  created_at: string;
  user_id: string;
  product_name: string;
  ncm_code: string;
  purchase_price: number;
  suggested_price: number;
  markup: number;
  profit_margin: number;
}
