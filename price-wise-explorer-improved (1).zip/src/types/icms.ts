
export interface ICMSInputs {
  merchandiseValue: number;
  ipi?: number;
  freight?: number;
  insurance?: number;
  origin: 'national' | 'imported';
  originState: string;
  originRate: number;
  amRate: number;
}

export interface ICMSCalculation {
  baseValue: number;
  icmsValue: number;
  method: 'interstate' | 'import';
  isValid: boolean;
}
