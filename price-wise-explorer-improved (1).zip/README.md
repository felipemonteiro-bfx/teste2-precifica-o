# Price Wise Explorer - Versão Aprimorada

## Visão Geral

O Price Wise Explorer é uma aplicação de precificação inteligente que ajuda empresas a calcular preços de produtos, considerando impostos, margens e preços de mercado. Esta versão aprimorada inclui melhorias significativas no cálculo automático de NCM, persistência de login e funcionalidades para departamentos de compras.

## Principais Melhorias Implementadas

### 1. Cálculo Automático de NCM

O sistema agora utiliza a Brasil API para buscar códigos NCM de forma automática e precisa:

- Integração com a API externa para obter dados atualizados de NCM
- Sistema de fallback para o banco de dados local quando a API não retorna resultados
- Determinação automática de categorias com base nas descrições dos produtos
- Função específica para buscar NCM por código exato

### 2. Persistência de Login Aprimorada

Implementamos um sistema robusto de persistência de sessão:

- Múltiplas camadas de armazenamento (localStorage e cookies)
- Verificação e renovação automática de sessões prestes a expirar
- Aumento do tempo de expiração da sessão para 30 dias
- Recuperação de sessão de cookies quando o localStorage falha

### 3. Dashboard para Departamentos de Compras

Adicionamos um dashboard completo para equipes de compras:

- Visão geral com métricas-chave (total de compras, economia estimada, compras pendentes)
- Gráficos de análise por categoria e status
- Tabela detalhada de compras com filtro de busca
- Exportação de dados para CSV
- Análises avançadas de economia por categoria e fornecedor

## Tecnologias Utilizadas

- React com TypeScript
- Supabase para autenticação e armazenamento
- Brasil API para dados de NCM
- Recharts para visualizações gráficas
- Tailwind CSS e shadcn/ui para interface

## Como Executar o Projeto

```bash
# Instalar dependências
npm install

# Iniciar o servidor de desenvolvimento
npm run dev
```

## Estrutura do Projeto

- `/src/components` - Componentes da interface, incluindo o novo dashboard de compras
- `/src/contexts` - Contextos React, incluindo o AuthContext aprimorado
- `/src/hooks` - Hooks personalizados para cálculos e lógica de negócios
- `/src/lib` - Configurações e utilitários, incluindo a configuração aprimorada do Supabase
- `/src/utils` - Funções utilitárias, incluindo o novo sistema de cálculo de NCM

## Recomendações para Desenvolvimento Futuro

1. **Integração com APIs fiscais adicionais** - Expandir para incluir outras APIs fiscais para cálculos mais precisos de impostos específicos por estado.

2. **Sistema de gerenciamento de fornecedores** - Implementar um módulo completo para cadastro e avaliação de fornecedores.

3. **Histórico de preços e análise de tendências** - Adicionar funcionalidades para acompanhar a evolução de preços ao longo do tempo.

4. **Integração com sistemas ERP** - Desenvolver conectores para sistemas ERP populares para sincronização de dados.

5. **Aplicativo móvel** - Criar uma versão móvel para consultas rápidas e aprovações em trânsito.

## Contato

Para mais informações ou suporte, entre em contato através do email: [monteirofelipe.adv@gmail.com](mailto:monteirofelipe.adv@gmail.com)
